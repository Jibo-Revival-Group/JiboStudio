declare namespace Electron {

    export interface BrowserWindowOptions {
        x?:number;
        y?:number;
        width?:number;
        height?:number;
        fullscreen?:boolean;
        kiosk?:boolean;
        title?:string;
        show?:boolean;
        frame?:boolean;
        backgroundColor?:string;
        useContentSize?:boolean;
        resizable?:boolean;
    }
}

declare module "electron" {
    import {EventEmitter} from 'events';

    class Debugger extends EventEmitter {
        attach():void;
    }

    class WebContents extends EventEmitter {
        send(channel:string, ...args);
        debugger:Debugger;
    }

    class IPC extends EventEmitter {
        new();
        send(channel:string, ...args);
        sendSync(channel:string, ...args);
    }

    class CommandLine {
        appendSwitch(command:string): void;
    }

    class App extends EventEmitter {
        // on(event:"ready", listener:() => void): this;
        // on(event:"window-all-closed", listener:() => void): this;
        // on(event:"before-quit", listener:(event:Event) => void): this;
        // on(event:"will-quit", listener:(event:Event) => void): this;
        // on(event:"quit", listener:(event:Event, exitCode:number) => void): this;
        quit():void;
        exit(exitCode:number):void;
        focus():void;
        hide():void;
        show():void;
        getAppPath():string;
        getPath(name:string):string;
        setPath(name:string, path:string):void;
        getVersion():string;
        getName():string;
        commandLine:CommandLine;
        makeSingleInstance(callback:Function):void;
    }

    class GlobalShortcut {
        register(shortcut:string, callback:Function): void;
    }

    export class Menu {
        static buildFromTemplate(template:any[]):Menu;
        static setApplicationMenu(menu:Menu):void;
    }

    export class BrowserWindow extends EventEmitter {
        static getAllWindows():Array<BrowserWindow>;
        static getFocusedWindow():BrowserWindow;
        id:string;
        constructor(options?:Electron.BrowserWindowOptions);
        destroy():void;
        close():void;
        focus():void;
        isFocused():boolean;
        show():void;
        showInactive():void;
        hide():void;
        maximize():void;
        unmaximize():void;
        setFullScreen(flag:boolean):void;
        setBounds(options:{x:number, y:number, width:number, height:number}):void;
        setSize(width:number, height:number):void;
        setAlwaysOnTop(flag:boolean):void;
        center():void;
        setPosition(x:number, y:number):void;
        loadURL(url:string, options?:any):void;
        openDevTools(options?:any);
        reload():void;
        webContents:WebContents;
    }

    export var ipcMain:IPC;
    export var ipcRenderer:IPC;
    export var app:App;
    export var globalShortcut:GlobalShortcut;

}