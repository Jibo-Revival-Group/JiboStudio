declare module "animation-utilities" {
    export var THREE:any;
    export var visualize:any;
    export var MouseCoordinateWrangler:any;
    export var MouseTargetPositioner:any;
    export var JiboConfig:any;
    export var RobotInfo:any;
}
