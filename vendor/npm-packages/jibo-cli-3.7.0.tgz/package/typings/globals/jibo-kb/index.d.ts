declare module "jibo-kb" {
    var kb:any;
    export var KnowledgeBase;
}
