declare module "find-root" {
    function findRoot(dir?:string):string;
    export = findRoot;
}