declare module "skills-service-manager" {
    export var LPSService:any;
    export var ASRService:any;
    export var Factory:any;
    export var KBService:any;
    export var TTSService:any;
    export var NotificationsService:any;
    export var BodyService:any;
    export var RegistryClient:any;
    export var ListenService:any;
    export var GlobalListen:any;
}