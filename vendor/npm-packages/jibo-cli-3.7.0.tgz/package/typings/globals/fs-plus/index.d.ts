declare module 'fs-plus' {
    export * from 'fs';
    export function isFileSync(path: string): boolean;
    export function makeTreeSync(directoryPath:string):string;
    export function isDirectorySync(directoryPath:string):boolean;
}