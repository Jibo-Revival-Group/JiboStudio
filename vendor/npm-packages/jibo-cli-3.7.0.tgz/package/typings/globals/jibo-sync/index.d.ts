declare module "jibo-sync" {
    export function uploadToServer(syncUrl:string, skillPath:string, closeServerWhenDone:boolean, verbose:boolean, callback:(error:any, msg?:string)=>void):void;
    export function closeServer(syncUrl, callback:(error:any, msg?:string) => void):void;
    export function stop():void;
}