declare module "electron-prebuilt" {
    var _electron:string;
    export = _electron;
}