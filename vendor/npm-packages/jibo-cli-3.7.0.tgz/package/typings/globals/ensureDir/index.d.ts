declare module "ensureDir" {
    function _ensureDir(path:string, permission:number, callback:(err:any) => void): void;
    export = _ensureDir;
}