declare module "compute-hamming" {
    var hamming:(str1:string, str2:string) => number;
    export = hamming;
}