/// <reference path="globals/electron/index.d.ts" />
/// <reference path="globals/commander/index.d.ts" />
/// <reference path="globals/react/index.d.ts" />
/// <reference path="../../jibo/typings/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/marked/index.d.ts" />
/// <reference path="globals/jibo-kb/index.d.ts" />
/// <reference path="globals/skills-service-manager/index.d.ts" />
