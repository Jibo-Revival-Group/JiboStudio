/// <reference path="globals/node-4/index.d.ts" />
/// <reference path="globals/electron/index.d.ts" />
/// <reference path="globals/commander/index.d.ts" />
/// <reference path="globals/find-root/index.d.ts" />
/// <reference path="globals/lodash/index.d.ts" />
/// <reference path="globals/fs-extra/index.d.ts" />
