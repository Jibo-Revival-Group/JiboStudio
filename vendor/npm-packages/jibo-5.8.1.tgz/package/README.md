# jibo

Main entry point into the Jibo API. 

## Installation

Install using NPM.

```bash
npm install jibo --save
```

## Usage

To initialize Jibo and related services, call `jibo.init`. The first argument to `init` is the DOM ID of the `<div>` element that will contain the rendering view for jibo. 

### index.html

```html
<div id="face"></div>
<script src="main.js"></script>
```

### main.js

```js
const jibo = require ('jibo');
const Status = jibo.bt.Status;

// 'face' is the DOM ID where to add face rendering
jibo.init('face', (err) => {
    if (err) {
        return console.error(err);
    }
    // Run a behavior tree and handle the result
    jibo.bt.run('./behaviors/main', (status) => {
        console.log('Finished with status: %s', status);
    });
});
```