import EventEmitter = require('jibo-eventemitter3');
import { EventContainer, Event } from 'jibo-typed-events';
import * as HammerJS from 'hammerjs';
import 'pixi-animate';
import sound from './sound';
import * as kb from './kb';

declare namespace rendering {

    interface DOFValues {
        eyeSubRootBn_t:number;
        eyeSubRootBn_t_2:number;
        vertexJoint1_t:number;
        vertexJoint1_t_2:number;
        vertexJoint2_t:number;
        vertexJoint2_t_2:number;
        vertexJoint3_t:number;
        vertexJoint3_t_2:number;
        vertexJoint4_t:number;
        vertexJoint4_t_2:number;
        vertexJoint5_t:number;
        vertexJoint5_t_2:number;
        vertexJoint6_t:number;
        vertexJoint6_t_2:number;
        vertexJoint7_t:number;
        vertexJoint7_t_2:number;
        vertexJoint8_t:number;
        vertexJoint8_t_2:number;
        vertexJoint9_t:number;
        vertexJoint9_t_2:number;
        eye_alphaChannelBn_r:number;
        eye_redChannelBn_r:number;
        eye_greenChannelBn_r:number;
        eye_blueChannelBn_r:number;
        eyeVisibilityBn_r:number;
        eyeTextureInfixBn_r:string;
        eyeSubRootBn_r:number;

        //overlay
        overlay_textureSubRootBn_t:number;
        overlay_textureSubRootBn_t_2:number;
        overlay_textureSubRootBn_r:number;
        overlay_vertexJoint1_t:number;
        overlay_vertexJoint1_t_2:number;
        overlay_vertexJoint2_t:number;
        overlay_vertexJoint2_t_2:number;
        overlay_vertexJoint3_t:number;
        overlay_vertexJoint3_t_2:number;
        overlay_vertexJoint4_t:number;
        overlay_vertexJoint4_t_2:number;
        overlay_vertexJoint5_t:number;
        overlay_vertexJoint5_t_2:number;
        overlay_vertexJoint6_t:number;
        overlay_vertexJoint6_t_2:number;
        overlay_vertexJoint7_t:number;
        overlay_vertexJoint7_t_2:number;
        overlay_vertexJoint8_t:number;
        overlay_vertexJoint8_t_2:number;
        overlay_vertexJoint9_t:number;
        overlay_vertexJoint9_t_2:number;
        overlay_alphaChannelBn_r:number;
        overlay_redChannelBn_r:number;
        overlay_greenChannelBn_r:number;
        overlay_blueChannelBn_r:number;
        overlayVisibilityBn_r:number;
        overlayTextureInfixBn_r:string;

        screenBGTextureInfixBn_r:string;
        screenBG_redChannelBn_r:number;
        screenBG_greenChannelBn_r:number;
        screenBG_blueChannelBn_r:number;

        //doesn't render to screen
        lightring_redChannelBn_r:number;
        lightring_greenChannelBn_r:number;
        lightring_blueChannelBn_r:number;
        bottomSection_r:number;
        middleSection_r:number;
        topSection_r:number;
    }

    export namespace animation {
        // region animation
        class Layer {}

        class Keyframes {
            public version:string;
            public framerate:number;
            public duration:number;
            public scale:number;
            public layers:KeyframesLayer[];
        }

        class KeyframesLayer {
            public id:string
            public name:string;
            public type:string;
            public visible:boolean;
            public locked:boolean;
            public keyframes:any[];
            public validFrom:number;
            public validUpto:number;
            public holdAfter:number;
        }

        export class KeysLoader {
            public constructor(src:string);
            public load(callback:Function):void;
            public load():Promise<Keyframes>;
        }

        export class KeysAnimation extends EventEmitter {
            public static FRAMERATE:number;
            public static STARTED:string;
            public static STOPPED:string;
            public static EVENT:string;
            public static CANCELLED:string;
            public static PLAY_AUDIO:string;
            public static PLAY_TIMELINE:string;
            public static REORDER:string;
            public assetPack:string;
            public root:string;
            public timelines:{[file:string]: Timeline};
            public sounds:{[file:string]: sound.Sound};
            public id:string;
            public layers:Layer[];
            public builder:any;
            public data:any;
            public isCopy:boolean;
            public update(time:number, dofValues:DOFValues):void;
            public reset():void;
            public addSound(id:string, sound:sound.Sound): void;
            public addTimeline(id:string, timeline:Timeline): void;
            public playSync(instance:PIXI.animate.MovieClip, event?:string|Function, callback?:Function): void;
            public destroy():void;
            public getCleanCopy():KeysAnimation;
        }

        export class Shapes {
            public destroy():void;
        }

        export class Spritesheet {
            public frames:{[id:string]: PIXI.Texture};
            public destroy();
        }

        interface Library {
            stage:any;
            background:number;
            width:number;
            height:number;
            framerate:number;
            totalFrames:number;
            library:any;
        }

        export class Timeline {
            public instance:any;
            public shapes:Shapes;
            public library:Library;
            public upload(renderer:PIXI.WebGLRenderer, callback:any): void;
            public destroy():void;
        }
        // endregion animation
    }

    

    export namespace gui {
        // region gui
        
        export namespace actions {
            // region actions
            interface ActionDescriptor {
                type:string;
                data?:any;
            }
            export class ActionData {
                public static OPEN_VIEW:string;
                public static CLOSE_VIEW:string;
                public static CLOSE_VIEW_EMPTY:string;
                public static CLOSE_ALL:string;
                public static CLOSE_ALL_OPEN:string;
                public static CLOSE_ALL_EMPTY:string;
                public static SWIPE_RIGHT:string;
                public static SWIPE_LEFT:string;
                public static SWIPE_DOWN:string;
                public static GO_TO_BEGINNING:string;
                public static GO_TO_END:string;
                public static EVENT:string;
                public static UTTERANCE:string;
                public static VERBAL_COMMAND:string;
                public static MIM_END:string;
                public static MIM_SHOW_GUI:string;
                public static CALLBACK:string;
                public type:string;
                public data:any;
                public static createFromConfig(configData:ActionDescriptor):ActionData;
                constructor(type?:string, data?:any);
                public applyConfig(configData:ActionDescriptor):void;
            }
            // endregion actions
        }
        
        interface AssetDescriptor {
            id:string;
            type:string;
            src:string;
            upload?:boolean;
            instance?:boolean;
        }
        export abstract class Component extends EventEmitter {
            public id:string;
            public type:string;
            public parentGroup:ComponentGroup;
            public stateChanged:boolean;
            public inputLocked:boolean;
            public assetDescriptors:AssetDescriptor[];
            protected _type:string;
            protected _stateChanged:boolean;
            protected _assetDescriptors:AssetDescriptor[];
            protected _assets:any;
            protected _inputLocked:boolean;
            public abstract updateConfig(configData:any):any;
            public abstract createDisplay(container:PIXI.Container, assets:any):void;
            public abstract update(elapsed:number):void;
            public abstract ready():void;
            public assignConfig(configData:any):void;
            public registerUpdate(bool:boolean):void;
            public destroy():void;
            public open(callback:Function, transitionType?:string):void;
            public close(callback:Function, transitionType?:string):void;
            public addAssetDescriptor(id:string, src:string, type:string):any;
            public addAssetDescriptorObject(assetDescriptor:AssetDescriptor):any;
            public hasTouchInteractive():boolean;
            public isTouchInteractive():boolean;
            public addAction(action:actions.ActionData|string, data?:any, clearPrevious?:boolean, toFront?:boolean, gesture?:string):actions.ActionData;
            public clearActions(gesture?:string):void;
            public removeActionsByType(actionType:string, gesture?:string):void;
            public triggerActions(gesture?:string):void;
            public hasActions(gesture?:string):boolean;
            public getActions(gesture?:string):actions.ActionData[];
            public lockInput(flag:boolean):void;
        }
        export abstract class ComponentGroup extends Component {
            public componentsTotal:number;
            public hitArea:PIXI.Container;
            protected _componentLibrary:any;
            protected _componentList:Component[];
            protected _componentConfigs:any[];
            protected _updateRegistry:Component[];
            public updateConfig(configObject?:any):any;
            public addComponent(component:Component, componentId?:string):Component;
            public getComponentById(componentId:string):Component;
            public getComponentByIndex(index:number):Component;
            public update(elapsed:number):void;
            public registerComponentUpdate(component:Component):void;
            public unregisterComponentUpdate(component:Component):void;
            public createDisplay(container:PIXI.Container, assets:any):void;
            public ready():void;
            public open(callback:Function, transitionType?:string):void;
            public close(callback:Function, transitionType?:string):void;
            public actionHandler(action:actions.ActionData, fromComponent?:Component):void;
            public actionEnactor(action:actions.ActionData):boolean;
            public destroy();
            protected updateComponentConfigs():boolean;
            protected createComponentsFromConfigs(componentConfigs:any[]):void;
            protected transitionComplete(callback:Function, err?:Error, results?:any[]):void;
            protected lockChildInput(flag:boolean):void;
        }
        export class ViewState {
            public id:string;
            public configPath:string;
            public viewClassName:string;
            public viewConfig:any;
            public componentConfigs:any[];
            public pauseParent:boolean;
            public ignoreSwipeDown:boolean;
            constructor(viewClassName?:string, config?:any);
            public applyConfig(config:any):void;
        }

        export namespace components {
            export abstract class Element extends Component {
                public display:PIXI.Container;
                public index:number;
                public interactable:boolean;
                public targetPosition:PIXI.Point;
                protected _targetPosition:PIXI.Point;
                public assignConfig(configData:any):void;
                public updateConfig(configData:any):any;
                public update(elapsed:number):void;
                public createDisplay(container:PIXI.Container, assets?:any):void;
                public setupDisplay(assets?:any):void;
                public setTargetPosition(x?:number, y?:number, applyNow?:boolean):void;
                public applyPosition():void;
                public ready():void;
                public open(callback:Function, transitionType?:string, tweenTime?:number, tweenType?:string):void;
                public close(callback:Function, transitionType?:string, tweenTime?:number, tweenType?:string):void;
                public destroy():void;
                public lockInput(flag:boolean):void;
            }
            export class Button extends Element {
                protected _type:string;
                protected _isDown:boolean;
                static createFromConfig(configData:any):Button;
                public createDisplay(container:PIXI.Container, assets?:any);
                public setupDisplay(assets?:any):void;
                public destroy():void;
                public update(elapsed:number):void;
                public updateConfig(configData:any):any;
                public setupHitArea(bounds?:PIXI.Rectangle):void;
                public setupInteractions():void;
                public lockInput(flag:boolean):void;
                protected click(mouseData?:any);
                protected out(mouseData?:any);
                protected down(mouseData?:any);
                protected up(mouseData?:any);
                protected activate():void;
            }
            export class Clip extends Element {
                public static DEFAULT_TYPE:string;
                public timeline:animation.Timeline;
                public movieClip:PIXI.animate.MovieClip;
                public static createFromConfig(configData:any):Clip;
                public static createFromDisplayObject(displayObject:PIXI.DisplayObject, container?:PIXI.Container):Clip;
                public createDisplay(container:PIXI.Container, assets?:any);
                public setupDisplay(assets?:any):void;
            }
            interface FontStyle {
                fontSize:number|string;
                fontFamily:string;
                fill:string;
                fontStyle?:string;
            }
            export class Label extends Element {
                public static DEFAULT_TYPE:string;
                public style:FontStyle;
                public textDisplay:PIXI.Text;
                public targetAnchor:PIXI.Point;
                public text:string;
                protected _targetAnchor:PIXI.Point;
                protected _text:string;
                public static createFontStyle(size:number, family:string, color:string, style?:string):FontStyle;
                public static createFromConfig(configData:any):Label;
                public assignConfig(configData:any):void;
                public createDisplay(container:PIXI.Container, assets?:any):void;
                public setupDisplay(assets?:any):void;
                public getTextDimensions(sampleText?:string):PIXI.Point;
                public setTargetAnchor(x?:number, y?:number, applyNow?:boolean):void;
                public applyPosition():void;
                public open(callback?:Function, transitionType?:string, tweenTime?:number, tweenType?:string):void;
                public close(callback?:Function, transitionType?:string, tweenTime?:number, tweenType?:string):void;
            }
            export class List extends ComponentGroup {
                public static DEFAULT_TYPE:string;
                public static PAN:string;
                public static PAGED:string;
                public static AT_END:string;
                public static AT_FRONT:string;
                public elementsPerPage:number;
                public numElementsAtEdge:number;
                public elementDimensions:PIXI.Point;
                public elementBuffer:number;
                public defaultElementData:any;
                public axisPosition:number;
                public elementSpacing:number;
                public listStartPosition:PIXI.Point;
                public pageIndex:number;
                public noPan:boolean;
                protected _dynamicElements:boolean;
                protected _dynamicPreloadElements:boolean;
                protected _elementSpacing:number;
                protected _listStartPosition:PIXI.Point;
                public static createFromConfig(configData:any):List;
                public assignConfig(configData?:any):void;
                public addComponent(element:Element, elementId?:string):Element;
                public updateConfig(configData:any):any;
                public createDisplay(container:PIXI.Container, assets?:any):void;
                public setupDisplay(assets?:any):void;
                public ready():void;
                public open(callback:Function, transitionType?:string):void;
                public close(callback:Function, transitionType?:string):void;
                public destroy():void;
                public lockInput(flag:boolean):void;
                public getElementsByPage(page?:number):Component[];
                public getStartIndexByPage(pageIndex:number):number;
                public actionHandler(action:actions.ActionData, fromComponent?:Component):void;
                public actionEnactor(action:actions.ActionData):boolean;
                public update(elapsed:number):void;
                public changePage(pageForward?:boolean):boolean;
                public createComponentsFromConfigs(elementConfigs:any[], defaultElementData?:any):void;
                protected calculateReferenceValues():void;
                protected mergeConfigs(data:any, defaultData:any, mergeArrays?:boolean):any;
            }

            export class MenuButton extends Button {
                public static DEFAULT_TYPE:string;
                public static SKILL:string;
                public static ACTION:string;
                public static ACTION_BIG:string;
                public timelineId:string;
                public iconId:string;
                public colors:number[];
                public label:string;
                public dimensions:PIXI.Point;
                public sender:any;
                protected _dimensions:PIXI.Point;
                protected _content:PIXI.Container;
                protected _buttonDatas:{[type:string]:{assetPath:string, dimensions:PIXI.Point}};
                public static createFromConfig(configData:any):MenuButton;
                public applyButtonType(type?:string):void;
                public setupDisplay(assets?:any):void;
                protected setupTimeline(assets:any):void;
            }

            export class ContactButton extends Button {
                public static DEFAULT_TYPE:string;
                public willToggle:boolean;
                public isChecked:boolean;
                public looper:kb.UserNode;
                public static createFromConfig(configData:any):ContactButton;
                public setChecked(bool:boolean, animate?:boolean):void;
                public assignLooper(looper:kb.UserNode):void;
                protected setupTimeline(assets:any):void;
            }

            type AlbumInfo = {
                title: string,
                length: number
            };
            export class ContentButton extends Button {
                public static DEFAULT_TYPE:string;
                protected _isVideo:boolean;
                protected _albumInfo:AlbumInfo;
                public static createFromConfig(configData:any):ContentButton;
                public assignConfig(configData:any):void;
                protected setupTimeline(assets:any):void;
            }
        }

        export namespace views {
            interface PauseOptions {
                alpha:number;
                duration:number;
                type:string;
            }
            
            export class View extends ComponentGroup {
                public static DEFAULT_TYPE:string;
                public static INITIALIZED:string;
                public static DATA_LOADED:string;
                public static ASSETS_LOADED:string;
                public static LOADED:string;
                public static OPENED:string;
                public static CLOSED:string;
                public static DESTROYED:string;
                public static BACK:string;
                public static CATEGORY_GUI:string;
                public static CATEGORY_DISPLAY:string;
                public static CATEGORY_EYE:string;
                public assetManifest:AssetDescriptor[];
                public pausedParent:View;
                public swipeDownActions:actions.ActionData[];
                public closeOnSwipeDown:boolean;
                public willPauseParent:boolean;
                public transitionStageOnly:boolean;
                public stage:PIXI.Container;
                public viewManager:ViewManager;
                public soundSet:string;
                public assets:any;
                public state:string;
                public status:string;
                public category:string;
                protected _stage:PIXI.Container;
                protected _viewManager:ViewManager;
                protected _configPath:string;
                protected _viewConfig:any;
                protected _status:string;
                constructor (viewState?:ViewState);
                public init(viewManager:ViewManager, loadAssetsOnComplete?:boolean):void;
                public applyData():any;
                public loadAssets(loadedOnComplete?:boolean):void;
                public ready():void;
                public pause(flag?:boolean, pauseOptions?:PauseOptions):void;
                public destroy():void;
                public open(callback?:Function, transitionType?:string):void;
                public close(callback?:Function, transitionType?:string):void;
                public actionHandler(action:actions.ActionData, fromComponent?:Component):void;
                public assignConfig(viewConfig?:any):any;
                public applyState(viewState:ViewState):void;
                public createState():ViewState;
                public addAssets(assets:AssetDescriptor|AssetDescriptor[]|{[id:string]: AssetDescriptor}, callback?:Function):void;
                public removeAssets(assets:AssetDescriptor|AssetDescriptor[]|{[id:string]: AssetDescriptor}):void;
                public setupScreenClick();
                protected loadData(loadAssetsOnComplete?:boolean):void;
                protected resolveAssetDescriptors(assetQueue:AssetDescriptor[]):AssetDescriptor[];
                protected loaded():void;
                protected transitionVerticalIn(up:boolean, callback?:Function, moveEase?:string, tweenTime?:number):void;
                protected transitionVerticalOut(up:boolean, callback?:Function, moveEase?:string, tweenTime?:number):void;
                protected transitionHorizontalIn(forward:boolean, callback?:Function, moveEase?:string, tweenTime?:number):void;
                protected transitionHorizontalOut(forward:boolean, callback?:Function, moveEase?:string, tweenTime?:number):void;
                protected transitionFadeIn(callback?:Function, scaleEase?:string, fadeEase?:string, tweenTime?:number):void;
                protected transitionFadeOut(callback?:Function, scaleEase?:string, fadeEase?:string, tweenTime?:number):void;
                protected setupSwipeDownToClose():void;
            }
            export class MenuView extends View {
                public static DEFAULT_TYPE:string;
                public list:components.List;
                protected _title:components.Label;
                protected _list:components.List;
                protected _buttonLabels:components.Label[];
                public applyData():any;
                public destroy():void;
                public actionHandler(action:actions.ActionData, fromComponent?:Component):void;
                public updateConfig(configObject?:any):any;
                protected createListComponents(list:components.List):void;
                protected loaded():void;
                protected positionComponents(overrideTitleHeight?:number):void;
            }
            export class PauseOverlay {
                public alpha:number;
                public duration:number;
                public type:string;
                constructor(options?:PauseOptions);
                public applyOptions(options:PauseOptions):void;
                public applyDefaults():void;
                public open(container:PIXI.Container):void;
                public close():void;
                public destroy():void;
            }
        }
        export class ComponentCreator {
            public remove(viewClass?:any, config?:any):views.View;
            public createViewFromConfigObject(config:Object):views.View;
            public createViewFromConfigPath(configPath:string, complete:ViewCallback, failure?:Function):void;
            public createViewState(viewClass:any, config?:any):ViewState;
            public createViewFromState(viewState:ViewState):views.View;
            public createComponentFromConfig(componentConfig:any):Component;
            public registerClass(componentClass:any, classType?:string):void;
            public unregisterClass(classType:string):void;
            public getClassFromRegistry(className:string):any;
        }
        export class ViewGlobalEvents extends EventContainer {
            public process:Event<ViewProcessResult>;
            public view:Event<ViewResult>;
        }
        export class ViewProcessResult {
            public status:string;
            public currentId:string;
            public closingId:string;
        }
        export class ViewResult {
            public event:string;
            public status:string;
            public id:string;
            public type:string;
            public data:any;
        }
        
        export interface ChangeOptions {
            remove?:boolean;
            removeTo?:string;
            removeToInclude?:string;
            removeAll?:boolean;
            leaveEmpty?:boolean;
            addView?:string|views.View|any;
            transitionClose?:string;
            transitionOpen?:string;
            pauseOptions?:views.PauseOptions;
        }
        type ViewCallback = (view?:views.View, done?:Function) => any;
        export class ViewManager {
            public static TRANS_UP:string;
            public static TRANS_DOWN:string;
            public static TRANS_RIGHT:string;
            public static TRANS_LEFT:string;
            public static TRANS_IN:string;
            public static TRANS_OUT:string;
            public static TRANS_NONE:string;
            public stage:PIXI.Container;
            public currentView:views.View;
            public hitArea:PIXI.Container;
            public creator:ComponentCreator;
            public viewStackLength:number;
            public events:ViewGlobalEvents;
            public UP:string;
            public DOWN:string;
            public RIGHT:string;
            public LEFT:string;
            public IN:string;
            public OUT:string;
            public NONE:string;
            public INITIALIZED:string;
            public DATA_LOADED:string;
            public ASSETS_LOADED:string;
            public LOADED:string;
            public OPENED:string;
            public CLOSED:string;
            public BACK:string;
            public CATEGORY_GUI:string;
            public CATEGORY_DISPLAY:string;
            public CATEGORY_EYE:string;
            public SWIPE:string;
            public TAP:string;
            public getViewState(index?:number):ViewState;
            public createView(viewName?:string, config?:any, open?:boolean, onOpenComplete?:ViewCallback, openTransition?:string, closeTransition?:string):views.View;
            public createView(viewClass?:any, config?:any, open?:boolean, onOpenComplete?:ViewCallback, openTransition?:string, closeTransition?:string):views.View;
            public createViewFromConfigPath(configPath:string, open?:boolean, callback?:ViewCallback,  openTransition?:string, closeTransition?:string):void;
            public actionHandler(action:actions.ActionData, fromComponent?:Component, onComplete?:ViewCallback):void;
            public actionEnactor(action:actions.ActionData):boolean;
            public changeView(options:ChangeOptions, onComplete?:ViewCallback, onFailure?:Function, onLoaded?:ViewCallback):void;
            public addView(view:views.View, onAdded?:ViewCallback, openTransition?:string, closeTransition?:string, onFailure?:Function):void;
            public addView(viewConfigPath:string, onAdded?:ViewCallback, openTransition?:string, closeTransition?:string, onFailure?:Function):void;
            public removeView(onRemoved?:ViewCallback, openTransition?:string, closeTransition?:string, onFailure?:Function):void;
            public forceEyeView(onOpenCallback?:ViewCallback, onPressCallback?:any, openTransition?:string, closeTransition?:string, onFailure?:Function):void;
            public hasView(id:string):boolean;
        }
        // endregion gui
    }

    export namespace input {
        // region input
        export class GestureManager {
            public static PAN:string;
            public static PANSTART:string;
            public static PANMOVE:string;
            public static PANEND:string;
            public static PANCANCEL:string;
            public static PANLEFT:string;
            public static PANRIGHT:string;
            public static PANUP:string;
            public static PANDOWN:string;
            public static SWIPE:string;
            public static SWIPELEFT:string;
            public static SWIPERIGHT:string;
            public static SWIPEUP:string;
            public static SWIPEDOWN:string;
            public static TAP:string;
            public hammer: typeof HammerJS;
            public addStageGesture(hammerType:any, gestureOptions:any, gestureCallback: (hammerEvent:{}) => void):any;
            public removeStageGesture(gestureRecognizer):void;
            public spoofGesture(gestureEvent?:string, xPos?:number, yPos?:number):void;
        }
        // endregion input
    }

    export namespace tween {
        // region tween
        type TweenOptions = {
            to:any;
            from?:any;
            duration?:number;
            ease?:string;
            delay?:number;
        };
        export class Tween extends EventEmitter {
            paused:boolean;
            delay:number;
            duration:number;
            time:number;
            target:any;
            inProcess:boolean;
            init(target:any, options:TweenOptions, complete?:Function):void;
            reset(): void;
        }
        type SetOptions = {
            focus?:number;
            focusIsLast?:boolean;
            delay?:number;
            complete?:Function;
        };
        export class TweenManager {
            static paused:boolean;
            static play(target:any, options:TweenOptions, complete?:Function): Tween;
            static playSet(targets:any[], options:TweenOptions, setOptions?:SetOptions|Function): void;
            static stop(target?:any): void;
        }
        // endregion tween
    }

    export namespace eye {
        // region eye
        class EyeMesh extends PIXI.mesh.Mesh {
            public points:PIXI.Point[];
        }
        abstract class AbstractLayer extends PIXI.Container {
            connected:boolean;
            texturePath:string;
            init(texture:PIXI.Texture):void
            display(timestamp:number[], dofValues:DOFValues):boolean;
            destroy():void;
        }
        abstract class AbstractEye extends AbstractLayer{
            eyeMesh:EyeMesh;
        }

        class Eye extends AbstractEye {}

        class EyeOverlay extends AbstractEye {}

        class Background extends AbstractLayer {
            sprite:PIXI.Sprite;
        }

        export namespace filters {

            export class GlowFilter extends PIXI.Filter {
                constructor();
                uniforms: any;
                haloDistance: number;
                target:any;
                enabled:boolean;
                amount: number;
                blur: number;
                haloSpeed: number;
                blurQuality: number;
                haloMaxDistance: number;
                halo: number;
                color: any;
            }

            export class LightFilter extends PIXI.Filter {
                constructor();
                radius:number;
                lightScale:number;
                distanceMagnification: PIXI.Point;
                lightPosition: PIXI.Point;
                uniforms:any;
                enabled:boolean;
                target:any;
                amount: number;
                dark: any;
                mid: any;
                light: any;
                brightness: number;
                gradientRatio: number;
            }
        }

        export class EyeContainer extends PIXI.Container {
            eye:Eye;
            glow: filters.GlowFilter;
            lighting: filters.LightFilter;
            eyeOverlay:EyeOverlay;
            stage:PIXI.Container;
            backgroundBorder:PIXI.Graphics;
            background:Background;
            connected:boolean;
            animation:animation.KeysAnimation;
            active:boolean;
            zoom:number;
            display(timestamp:number[], dofValues:DOFValues, meta?:any):void;
            makeBorder():void;
        }
        // endregion eye
    }

    export class FaceRenderer extends PIXI.WebGLRenderer {
        static WIDTH:number;
        static HEIGHT:number;
        active:boolean;
        stage:PIXI.Container;
        views:gui.ViewManager;
        gestures:input.GestureManager;
        tween:typeof tween.TweenManager;
        eye:eye.EyeContainer;
        paused:boolean;
        destroy():void;
    }
}

export default rendering;
