import {ParseResults} from 'jibo-common-types';

export type ParseResults = ParseResults;

declare type ParseCallback = (error:Error|string, result:ParseResults)=>void;
export default class NLUService {
    init(service:any, done:Function): void;
    compile(rule:string, callback:(error:string, uri:string)=>void, handle?:string):void;
    parseFromRule(rule:string, text:string, callback:ParseCallback, messageId?:string):void;
    parseFromURI(ruleHandle:string, text:string, callback:ParseCallback, messageId?:string):void;
    union(uris:string[], callback:(error:string, uri:string)=>void, ruleHandle?:string):void;
    parseFromFile(fstUri:string, text:string, callback:ParseCallback, messageId?:string):void;
    compileFromFst(fst:string, callback:(error:string, uri:string)=>void, handle?:string):void;
    removeFromMemory(uri:string, callback:(error:string, uri:string)=>void)
    saveFstOnDisk(uri:string, filePath: string, callback:(error:string, uri:string)=>void)
    resetMemory(callback:(error:string, uri:string)=>void)
}