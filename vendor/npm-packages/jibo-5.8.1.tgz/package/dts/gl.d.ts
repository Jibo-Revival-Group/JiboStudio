import { Event, EventContainer } from 'jibo-typed-events';
import EventEmitter = require('jibo-eventemitter3');
import {ParseResults} from './nlu';
import {Utterance, ListenResults} from 'jibo-common-types';

export type Utterance = Utterance;
export type ListenResults = ListenResults;

declare interface SpeakerId {
    speaker_id_status:string;
    speaker_ids:string[];
}
declare class StateEvents extends EventContainer {
    cloudReceived: Event<ListenResults>;
    listenFinished: Event<any>;
    incremental: Event<ParseResults>;
    hjHeard: Event<ListenResults>;
    hjOnly: Event<ListenResults>;
    speakerId: Event<SpeakerId>;
    eos: Event<any>;
    sos: Event<any>;
    startHjListen: Event<any>;
    noGlobalMatch: Event<any>;
    startNonHjListen: Event<any>;
    skillRelaunch: Event<any>;
    glStopped: Event<any>;
    glStarted: Event<any>;
    enrollment: Event<any>;
    global: Event<any>;
    socketClose: Event<string>;
    socketReopen: Event<string>;
 }
declare class GlobalEvent <Type> extends Event <Type> {
}
declare class GlobalEvents extends EventContainer {
    stop: GlobalEvent<ListenResults>;
    help: GlobalEvent<ListenResults>;
    sleep: GlobalEvent<ListenResults>;
    pause: GlobalEvent<ListenResults>;
    volume: GlobalEvent<ListenResults>;
    whatCanIDo: GlobalEvent<ListenResults>;
}
declare type ListenOptions = {
    incremental?:boolean;
    parseIncremental?:boolean;
    speech_to_text?:boolean;
    hotphrase?:string;
    verbose?:boolean;
    language?: string;
    forceGlobal?:boolean;
}
declare class IncrementalResults {
    result:ParseResults;
    stop():void;
}
declare class ListenerEvents extends EventContainer {
    cloudReceived: Event<ListenResults>;
    hjOnly: Event<ListenResults>;
    interrupted: Event<any>;
    incremental: Event<IncrementalResults>;
    eos: Event<any>;
    sos: Event<any>;
    hj: Event<any>;
    speakerId: Event<SpeakerId>;
    ruleCompiled: Event<string>;
    unsubscribed: Event<string>;
}
declare class ClientDialogListener {
    events: ListenerEvents;
    options: ListenOptions;
    ruleText: string;
}

declare class EnrollmentEvents extends ListenerEvents {
    startedEnrollment : Event<any>;
    savingAudio : Event<any>;
    needMoreData : Event<number>;
    finishedEnrollment : Event<any>;
    stoppedEnrollment : Event<any>;
    failedEnrollment : Event<any>;
}

declare class EnrollmentOptions {
    speakerId: string;
    enrollmentType: string;
    listenerId: string;
    action: string;
}

declare class EnrollmentListener {
    events: EnrollmentEvents;
    _listenerId: string; //used to identify it to the GLService
    userId : string; //loopID of the user to enroll
    options : EnrollmentOptions;

}

export default class GLService extends EventEmitter {
    events:StateEvents;
    global: GlobalEvents;
    verbose:boolean;
    subscribe(listener:ClientDialogListener, callback:(err:string, response?:any) => void):void;
    unsubscribe(listener:ClientDialogListener, callback:(err:string, response?:any) => void):void;
    createDialogListener(options:ListenOptions, ruleData:string|{rule:string, type:string}):ClientDialogListener;
    createEnrollmentListener():EnrollmentListener;
}
