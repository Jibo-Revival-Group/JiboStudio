export default class VersionsPlugin {
    ssm:string;
    platform:string;
    jibo:string;
    requiresPlatform:string;
    packageInfo:any;
    supported(version:string):boolean;
}