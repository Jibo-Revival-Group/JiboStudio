import EventEmitter = require('jibo-eventemitter3');

declare namespace mim {
    export interface Listener {
        stop(unsubscribe?:boolean):void;
        on(type:string, callback:Function):void;
    }
    export interface ListenDelegate {
        cleanupHandler?: (done:(error?)=>void)=>void;
        create(options:any, rulePath:string):Listener;
        setMode(mode:ListenModeOptions):void;
    }
    export interface SpeakDelegate {
        speak(options:any):Promise<any>;
        stop():void;
    }
    
    export class GlobalListenDelegate implements Listener {
        static cleanupHandler: (done:(error?)=>void)=>void;
        static create(options:any, rulePath:string):Listener;
        static setMode(mode:ListenModeOptions):void;
        stop(unsubscribe?:boolean):void;
        on(type:string, callback:Function):void;
    }
    
    export type ListenModeOptions = 'NORMAL'|'OPTIONAL_RESPONSE'|'NO_BODY'|'UI';
    
    export const ListenMode: {
        NORMAL: 'NORMAL',
        OPTIONAL_RESPONSE: 'OPTIONAL_RESPONSE',
        NO_BODY: 'NO_BODY',
        UI: 'UI'
    }
    
    //MimManager instance properties/methods
    export var listenDelegate:ListenDelegate;
    export var speakDelegate:SpeakDelegate;
    export var timeoutIgnoresSimulator:boolean;
}
export default mim;