import EventEmitter = require('jibo-eventemitter3');

declare var TTSMode: {
    SSML: 'ssml';
    TEXT: 'text';
};
declare var TTSEvents: {
    WORD: 'word';
    PHONE: 'phone';
    STOP: 'stop';
    EFFECT: 'effect';
    ANALYSIS: 'analysis';
};
declare type TTSOptions = {
    duration_stretch?:number;
    pitch?:number;
    pitchBandwidth?:number;
    mode?:'ssml'|'text';
    skipWordEvents?:boolean;
};
declare type WordTimings = {
    tokentimes: {
        tokens: {
            name: string,
            start: number,
            end: number
        }[];
    }
};

export default class TTSService extends EventEmitter {
    TTSMode: typeof TTSMode;
    TTSEvents: typeof TTSEvents;
    init(service:any, done:Function): void;
    speak(text:string, options?:TTSOptions):Promise<void>;
    speak(text:string, callback:(err?:any)=>void):void;
    speak(text:string, options:TTSOptions, callback:(err?:any)=>void):void;
    stop(callback:()=>void):void;
    stop():Promise<void>;
    getWordTimings(text:string, options?:TTSOptions):Promise<WordTimings>;
    getWordTimings(text:string, callback:(err:any, timings:WordTimings)=>void):void;
    getWordTimings(text:string, options:TTSOptions, callback:(err:any, timings:WordTimings)=>void):void;
    startEffect(name:string, value:string|number):void;
    stopEffect(name:string):void;
    updateEffect(name:string, value:string|number):void;
}