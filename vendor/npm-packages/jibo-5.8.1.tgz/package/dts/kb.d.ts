export * from 'jibo-kb';

import { ErrCallback } from 'jibo-kb';
import { CreateCallback } from 'jibo-kb';
import { ExistsCallback } from 'jibo-kb';
import { NodeConstructor } from 'jibo-kb';
import { ModelConstructor } from 'jibo-kb';
import { ServiceObject } from 'jibo-kb';
import { DatabaseManager } from 'jibo-kb';
import { LoopModel } from 'jibo-kb';
import { Model } from 'jibo-kb';

export var httpUrl:string;
export var databaseManager:DatabaseManager;
export var loop:LoopModel;
export var config:any;
//internal
export function init(service: ServiceObject, callback?: ErrCallback): void;
//internal
export function onInit(callback:ErrCallback);
export function onInit():Promise<void>;
//internal
export function initLoop(): void;
export function createSlice(sliceName:string, callback:CreateCallback): any;
export function createSlice(sliceName:string, httpUrl:string, callback:CreateCallback): any;
export function createSlice(sliceName:string, httpUrl?:string): Promise<boolean>;
export function existsSlice(sliceName:string, callback:ExistsCallback):void;
export function existsSlice(sliceName:string, httpUrl:string, callback:ExistsCallback):void;
export function existsSlice(sliceName:string, httpUrl?:string): Promise<boolean>;
export function createModel(sliceNames: string | string[], httpUrl?: string): Model;
export function registerNodeClass(nodeType: string, classConstructor: NodeConstructor, kbName?: string): void;
export function registerModelClass(kbNames: string | string[], classConstructor: ModelConstructor): void;
export function findNodeClass(nodeType: string, kbName: string): NodeConstructor;
export function findModelClass(kbNames: string | string[]): ModelConstructor;
export function removeSlice(sliceName:string, callback:ErrCallback): any;
export function removeSlice(sliceName:string):Promise<any>;
export function removeAll(callback:ErrCallback): any;
export function removeAll(): Promise<any>;
