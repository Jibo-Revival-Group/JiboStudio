export default class Lifecycle {
    finished(): void;
}