declare type InputEnergy = {
    ts:number[],      // Chronometer timestamp of this state
    db_rms:number,    // Overall dB RMS of input waveform
    db_high:number,   // ~1KHz dB RMS of input waveform
    db_mid:number,    // ~500Hz dB RMS of input waveform
    db_low:number     // ~200Hz dB RMS of input waveform
};

export default class SystemService {
    pluggedIn:boolean;
    batteryCharging:boolean;
    batteryChargeRate:number;
    inputEnergy:InputEnergy;
    getBatteryTemperature():number;
    getBatteryLevel():number;
    getSystemVoltage():number;
    getMainBoardTemperature():number;
    getCPUTemperature():number;
    getTouchState():{changed:number[], pad_state:boolean[]};
    getFanSpeed(callback:(error:string, speed:number)=>void):void;
    getBacklight(callback:(error:string, speed:number)=>void):void;
    setBacklight(value:number, callback:(error:string)=>void):void;
    index(callback:(error:string)=>void):void;
    getMasterVolume(callback:(error:string, volume:number)=>void):void;
    setMasterVolume(value:number, callback:(error:string)=>void):void;
}