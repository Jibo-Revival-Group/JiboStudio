import {Event, EventContainer} from 'jibo-typed-events';
import IdentityService from "./id";
declare enum PhotoType {
    DEBUG,
    PREVIEW,
    FULL
}
declare enum CameraID {
    LEFT,
    RIGHT
}
declare enum PhotoRes {
    SMALL = 1,
    MEDIUM,
    LARGE,
    XLARGE
}
declare type Entity = any;
declare type PreviewData = {
    enable:boolean;
    x?:number;
    y?:number;
    width?:number;
    height?:number;
};
export class LPSEvents extends EventContainer {
    audio: Event<any>;
    motion: Event<any>;
}
export default class LPSService {
    CameraID: typeof CameraID;
    PhotoType: typeof PhotoType;
    PhotoRes: typeof PhotoRes;
    events: LPSEvents;
    motionData: {cameras:any[], entities:Entity[]};
    audioData: any;
    identity: IdentityService;
    init(service:any, done:Function): void;
    getAudibleEntityById(id:string):Entity;
    getClosestAudibleEntity():Entity;
    getClosestVisualEntity():Entity;
    getVisibleEntityById(id:string):Entity;
    setPreview(data:PreviewData, callback:(error:string, result:any)=>void):void;
    takePhoto(photoRes:PhotoRes, noDistort:boolean, cameraID:CameraID, photoType:PhotoType, callback:(error:string, url:string)=>void):void;
}