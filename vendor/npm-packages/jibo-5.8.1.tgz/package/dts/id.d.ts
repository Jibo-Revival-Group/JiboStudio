import { Event, EventContainer } from 'jibo-typed-events';
declare interface PresenceEventData {
    reason:string;
}
declare interface Person{
    id: string;
    type: string;
}
declare interface IDEventData extends Person {
    reason:string;
}
declare class IdentityEvents extends EventContainer {
    presenceStarted: Event<PresenceEventData>;
    presenceEnded: Event<PresenceEventData>;
    idAcquired: Event<IDEventData>;
    idLost: Event<IDEventData>;
}
export default class IdentityService {
    events:IdentityEvents;
    isAnyonePresent():boolean;
    getPresentPersons():Person[];
    setPresentPerson(id: string);
    getActiveSpeaker():Person;
    awaitResolution(cb: Function);
    dispose();
}