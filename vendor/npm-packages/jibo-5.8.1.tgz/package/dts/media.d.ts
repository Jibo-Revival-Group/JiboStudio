declare namespace media_ns {

    export interface StorePhotoResult {
        id:string;
        thumbnails:{
            [key:string]:string;
            mobile?:string;
            robot?:string;
        };
    }

    export var recording:any;
    export function startRecording( options:any, callback:(err:Error, recordingInfo:any) => void );
    export function stopRecording( callback:(err:Error) => void );
    export function playRecording( options:any, callback:(err:Error) => void );
    export function storePhoto(buffer:Buffer, thumbnails:{[key:string]:[number, number]}, callback:(err:Error, result:StorePhotoResult) => void):void;
    export function getPhoto(id:string, callback:(err:Error, image:any) => void):void;
    export function getUrlById(id:string):string;
}

export default media_ns;