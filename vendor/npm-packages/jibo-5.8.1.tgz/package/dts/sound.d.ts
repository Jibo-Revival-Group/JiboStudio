import EventEmitter = require('jibo-eventemitter3');

declare namespace sound_ns {
    type SoundCompleteCallback = (sound:Sound) => void;
    type SoundLoadedCallback = (err:Error, sound?:Sound) => void;
    interface Options {
        autoPlay?:boolean;
        preaload?:boolean;
        block?:boolean;
        volume?:number;
        panning?:number;
        complete?:SoundCompleteCallback;
        loaded?:SoundLoadedCallback;
        preload?:boolean;
        loop?:boolean;
        src?:string;
        srcBuffer?:ArrayBuffer;
        useXHR?:boolean;
    }
    interface PlayOptions {
        offset?:number;
        complete?:SoundCompleteCallback;
        loaded?:SoundLoadedCallback;
    }
    export class Sound {
        isLoaded:boolean;
        isPlaying:boolean;
        autoPlay:boolean;
        complete:SoundCompleteCallback;
        loaded:SoundLoadedCallback;
        block:boolean;
        preload:boolean;
        src:string;
        srcBuffer:ArrayBuffer;
        useXHR:boolean;
        volume:number;
        loop:boolean;
        buffer:AudioBuffer;
        panning:number;
        instances:SoundInstance[];
        play(options?:PlayOptions|SoundCompleteCallback):SoundInstance;
        stop():Sound;
        pause():Sound;
        resume():Sound;
    }
    export class SoundInstance extends EventEmitter {
        paused:boolean;
        stop():void;
        play(offset?:number):void;
        destroy():void;
    }
    export class SoundUtils {
        static sineTone(hertz:number, seconds:number):Sound;
        static playOnce(src:string, callback?:(err?:Error) => void):string;
        static addClipSounds(clip:PIXI.animate.MovieClip, labelPrefix?:string, separator?:string): PIXI.animate.MovieClip;
    }
    
    export var basePath:string;
    export var baseUrl:string;
    export function add(alias:string, options:Options|string|ArrayBuffer):Sound;
    export function addMap(map:{string:Options|string|ArrayBuffer}, globalOptions?:Options):{[id:string]:Sound};
    export function remove(alias:string):typeof sound_ns;
    export function pauseAll():typeof sound_ns;
    export function resumeAll():typeof sound_ns;
    export function muteAll():typeof sound_ns;
    export function unmuteAll():typeof sound_ns;
    export function removeAll(): typeof sound_ns;
    export function stopAll():typeof sound_ns;
    export function exists(alias:string, assert?:boolean):boolean;
    export function sound(alias:string):Sound;
    export function play(alias:string, options?:PlayOptions|Object):SoundInstance;
    export function stop(alias:string):Sound;
    export function pause(alias:string):Sound;
    export function resume(alias:string):Sound;
}

export default sound_ns;