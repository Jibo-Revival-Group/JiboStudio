declare namespace animUtils_ns {
    export function initOutput(service:any): void;
    export function attachOutput(): void;
    export function detachOutput(): void;
    export function initUtilities(done:Function, headless?:boolean): void
}
export default animUtils_ns;