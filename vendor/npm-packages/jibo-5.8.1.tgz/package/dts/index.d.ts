import {Animate} from 'animation-utilities';
import utils_ns from './utils';
import GLService from './gl';
import bt_ns from './bt';
import flow_ns from './flow';
import NLUService from './nlu';
import LPSService from './lps';
import TTSService from './tts';
import SystemService from './system';
import SystemManager from './system-manager';
import animUtils_ns from './anim-utils';
import sound_ns from './sound';
import LoaderPlugin from './loader';
import mim_ns from './mim';
import media_ns from './media';
import rendering_ns from './rendering';
import * as _kb from './kb';
import Lifecycle from './lifecycle';
import VersionsPlugin from './versions';

declare namespace jibo {
    export const versions:VersionsPlugin;
    export const version:string;
    export const RunMode: {SIMULATOR:string, REMOTELY:string, ON_ROBOT:string, UNIT_TESTS:string};
    export import utils = utils_ns;
    export import animate = Animate;
    export const gl: GLService;
    export import bt = bt_ns;
    export import flow = flow_ns;
    export import kb = _kb;
    export import animUtils = animUtils_ns;
    export const nlu:NLUService;
    export const lps:LPSService;
    export import  media = media_ns;
    export const notifications:any;// TODO: API will probably change
    export const tts:TTSService;
    export const system:SystemService;
    export const systemManager:SystemManager;
    export const face:rendering_ns.FaceRenderer;
    export const timer:utils_ns.Timer;
    export import sound = sound_ns;
    export const loader:LoaderPlugin;
    export import mim = mim_ns;
    export const lifecycle:Lifecycle;
    export import rendering = rendering_ns;

    export const runMode:string;

    export function init(callback:(err?:string|Error)=>void):void;
    export function init(display:string|HTMLElement, callback:(err?:string|Error)=>void):void;
    export function init(options:{display:string|HTMLElement}, callback:(err?:string|Error)=>void):void;

    export type PluginCallback = (err?:string|Error) => void;
    export interface PluginConstructor {
        new (): Plugin;
    }
    export interface Plugin {
        api?: any;
        init(done:PluginCallback): void;
    }
    interface PluginOptions {
        api?:boolean;
        depends?:string[];
        electron?:boolean;
    }
}
export = jibo;
