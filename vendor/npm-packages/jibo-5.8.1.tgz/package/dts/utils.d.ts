import EventEmitter = require('jibo-eventemitter3');

declare namespace utils {
    type CompleteCallback = (call:DelayedCall) => void;
    export class Timer extends EventEmitter {
        paused:boolean;
        start():void;
        stop():void;
        update():void;
        setTimeout(callback:CompleteCallback, delay:number, useFrames?:boolean, autoDestroy?:boolean): DelayedCall;
        setInterval(callback:CompleteCallback, delay:number, useFrames?:boolean): DelayedCall;
        clearTimeout(call:DelayedCall):void;
        clearInterval(call:DelayedCall):void;
        destroy():void;
    }

    export class DelayedCall {
        parent:Timer;
        enabled:boolean;
        paused:boolean;
        constructor(parent:Timer, callback: CompleteCallback, delay: number, options?: any);
        update(elapsed:number):void;
        restart():void;
        stop():void;
        destroy():void;
    }

    export class PathUtils {
        static findRoot(start?:string): string;
        static getProjectName(dir:string): string;
        static setDefaultPath(parentDir:string, fileName:string):string;
        static getAssetPack(fileName:string):string;
        static getAssetUri(fileName:string, currentAssetPack?:string, resourceRoot?:string):string;
        static getAudioUri(fileName:string, currentAssetPack?:string, resourceRoot?:string):string;
        static getTimelineUri(fileName:string, currentAssetPack?:string, resourceRoot?:string):string;
        static resolve(moduleId:string):string;
        static resolveAssetPack(assetPack:string):string;
    }
}
export default utils;