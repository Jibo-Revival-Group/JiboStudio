import {EventEmitter} from 'events';

interface NotificationInterface {
    type:string;
    channel:string;
    ts:number[];
    data:any;
}
interface Identity {
    name:string;
    wifi_mac:string;
    serial_number:string;
}
export const NotificationEvents: {
    SHUTDOWN:string
};

type VersionCallback = (err:any, version?:string) => void;
type CredentialsCallback = (err:any, credentials?:any) => void;
type ModeCallback = (err:any, mode?:string) => void;
type TimeCallback = (err:any, time?:number) => void;
type TimeZoneCallback = (err:any, timezone?:string) => void;
type UpdatesCallback = (err:any, metadata?:any) => void;
type ErrCallback = (err?:any) => void;
type IdentityCallback = (err:any, identity: Identity) => void;

export default class SystemManager extends EventEmitter {
    notifications:NotificationInterface;
    NotificationEvents: typeof NotificationEvents;
    httpInterface:string;
    socketUrl:string;
    loggingEnabled:boolean;
    platform:string;
    constructor();
    init(service:any, done:Function): void;
    setLogging(logging:boolean): void;
    getVersion(callback:VersionCallback): void;
    getDisplayVersion(callback:VersionCallback): void;
    getCredentials(callback:CredentialsCallback): void;
    setCredentials(credentials:any, callback:ErrCallback): void;
    getMode(callback:ModeCallback): void;
    setMode(mode:string, callback:ErrCallback): void;
    getCurrentTime(callback:TimeCallback): void;
    syncTime(callback:ErrCallback): void;
    getTimeZone(callback:TimeZoneCallback): void;
    checkForUpdates(callback:UpdatesCallback, filter?:string): void;
    downloadUpdates(metadata:any, callback:UpdatesCallback): void;
    installUpdates(data:any, callback:ErrCallback): void;
    getIdentity(callback:IdentityCallback): void;
}