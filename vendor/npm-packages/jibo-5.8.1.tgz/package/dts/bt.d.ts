import EventEmitter = require('jibo-eventemitter3');
import {ParseResults} from './nlu';
import {Animate} from 'animation-utilities';
import rendering from './rendering';

declare namespace bt {
    export enum Status {
        SUCCEEDED,
        FAILED,
        INTERRUPTED,
        IN_PROGRESS,
        INVALID,
        PAUSED,
        WAIT
    }

    export class BehaviorEmitter extends EventEmitter {}

    class BaseElement {
        blackboard:any;
        emitter:BehaviorEmitter;
        options:any;
        assetPack: string;
        name:string;
        currentStatus:Status;
        start():boolean;
        stop():Promise<void>;
        destroy():void;
    }

    type BehaviorOptions = {
        name?:string;
        decorators?:Decorator[];
        blackboard?:any;
        emitter?:BehaviorEmitter;
        assetPack?:string;
    };

    export class Behavior extends BaseElement {
        parent:ParentBehavior;
        decorators:Decorator[];
        constructor(options?:BehaviorOptions, defaultOptions?:any);
        update(result?:Status):Status;
    }

    export class BehaviorTree extends EventEmitter {
        currentStatus: Status;
        start():boolean;
        stop():Promise<void>;
        update():Status;
        destroy():void;
    }

    type DecoratorOptions = {
        name?:string;
        blackboard?:any;
        emitter?:BehaviorEmitter;
        assetPack?:string;
    };

    export class Decorator extends BaseElement {
        behavior: Behavior;
        constructor(options?:DecoratorOptions, defaultOptions?:any);
        update(result:Status):Status;
    }

    // TODO: extends BehaviorOptions?
    type ParentBehaviorOptions = {
        children?:Behavior[];
    };
    export class ParentBehavior extends Behavior {
        children: Behavior[];
        constructor(options?:ParentBehaviorOptions, defaultOptions?:any);
    }
    
    export namespace behaviors {
        // region Behavior definitions
        export class Blink extends Behavior {}

        export class ExecuteScript extends Behavior {
            constructor(options: BehaviorOptions & {exec:()=>void});
        }

        export class ExecuteScriptAsync extends Behavior {
            constructor(options: BehaviorOptions & {exec:(succeed:()=>void, fail:()=>void)=>void});
        }

        class ListenEmitter extends EventEmitter {
        }
        type ListenBehaviorOptions = {
            heyJibo?:boolean;
            detectEnd?:boolean;
            incremental?:boolean;
            authenticateSpeaker?:string;
        };
        export class Listen extends Behavior {
            constructor(options: BehaviorOptions & {rule:string, getOptions:()=>ListenBehaviorOptions, onResult:(listener:ListenEmitter)=>void});
        }

        export class ListenEmbedded extends Behavior {
            constructor(options: BehaviorOptions & {rule:string, onResult:(listener:ListenEmitter)=>void});
        }

        type Point3D = {
            x: number;
            y: number;
            z: number;
        };
        export class LookAt extends Behavior {
            constructor(options: BehaviorOptions & {getTarget:()=>Point3D, isContinuous?:boolean, config?:any});
        }

        class MimASRResult {
            data: ParseResults;
            Input: string;
            NLParse: any;
            heuristic_score: number;
            slotIds: string[];
        }
        type MimResult = {
            state: MimState,
            asrResults: MimASRResult
        };
        class MimState {
            tries:number;
            noInputCount:number;
            noMatchCount:number;
            lastResultState:string;
            success:boolean;
            failure:boolean;
        }
        export class Mim extends Behavior {
            constructor(options: BehaviorOptions & {
                            mimPath:string,
                            getPromptData:()=>any,
                            onStatus?:(results:MimResult)=>void,
                            onSuccess?:(results:MimResult)=>void,
                            onFailure?:(results:MimResult)=>boolean|void
                        });
        }

        export class Menu extends Behavior {
            constructor(options: BehaviorOptions & {
                            getConfig:(callback:(config:any)=>void)=>void,
                            onMenuClosed:(timedOut:boolean, menu:rendering.gui.views.View, overrideMenuTransition:(trans:'remain'|rendering.gui.ChangeOptions)=>void)=>boolean|void,
                            onItemChosen:(result:any, menu:rendering.gui.views.View, overrideMenuTransition:(trans:'remain'|rendering.gui.ChangeOptions)=>void)=>void,
                            onPositionalSelect:(commandASR:MimASRResult, intendedIndex:number, menu:rendering.gui.views.View)=>void
                        });
        }

        export class Null extends Behavior {}

        export class Parallel extends ParentBehavior {
            constructor(options: ParentBehaviorOptions & {succeedOnOne?:boolean});
        }

        export class PlayAnimation extends Behavior {
            constructor(options: BehaviorOptions & {animPath:string, upload?:boolean, cache?:boolean, config?:any});
        }

        export class PlayAudio extends Behavior {
            constructor(options: BehaviorOptions & {audioPath:string, cache?:boolean});
        }

        export class Random extends ParentBehavior {
            constructor(options: ParentBehaviorOptions);
        }

        export class ReadBarcode extends Behavior {
            constructor(options: BehaviorOptions & {onBarcode:(error:string, data:{type:number, content:string})=>void});
        }

        export class Sequence extends ParentBehavior {
            constructor(options: ParentBehaviorOptions);
        }

        export class Subtree extends Behavior {
            constructor(options: BehaviorOptions & {behaviorPath:string|Function, getNotepad:()=>any, onResult:(result:any)=>void});
        }

        export class SubtreeJs extends Behavior {
            constructor(options: BehaviorOptions & {getTree:()=>string|Function, getNotepad:()=>any, onResult:(result:any)=>void});
        }

        export class Switch extends ParentBehavior {
            constructor(options: ParentBehaviorOptions);
        }

        export class TakePhoto extends Behavior {
            constructor(options: BehaviorOptions & {resolution:number, onPhoto:(url:string)=>void, noDistortion?:boolean});
        }

        export class TextToSpeech extends Behavior {
            constructor(options: BehaviorOptions & {words:string, onWord:(word:string)=>void});
        }

        export class TextToSpeechJs extends Behavior {
            constructor(options: BehaviorOptions & {getWords:()=>string, onWord:(word:string)=>void});
        }

        export class TimeoutJs extends Behavior {
            constructor(options: BehaviorOptions & {getTime:()=>number});
        }
        // endregion Behavior definitions
    }

    export namespace decorators {
        // region Decorator definitions
        export class Case extends Decorator {
            constructor(options:DecoratorOptions & {conditional:()=>boolean});
        }

        export class FailOnCondition extends Decorator {
            constructor(options:DecoratorOptions & {init?:()=>void, conditional:()=>boolean});
        }

        export class StartOnAnimEvent extends Decorator {
            constructor(options:DecoratorOptions & {eventName:string, onReceived:(instance:Animate.AnimationInstance, payload:any)=>void});
        }

        export class StartOnCondition extends Decorator {
            constructor(options:DecoratorOptions & {init?:()=>void, conditional:()=>boolean});
        }

        export class StartOnEvent extends Decorator {
            constructor(options:DecoratorOptions & {eventName:string, onEvent:(payload:any)=>void});
        }

        export class SucceedOnCondition extends Decorator {
            constructor(options:DecoratorOptions & {init?:()=>void, conditional:()=>boolean});
        }

        export class EmbeddedListenEmitter extends EventEmitter {}
        export class SucceedOnEmbedded extends Decorator {
            constructor(options:DecoratorOptions & {rule:string, onResult:(listener:EmbeddedListenEmitter)=>void});
        }

        export class SucceedOnEvent extends Decorator {
            constructor(options:DecoratorOptions & {eventName:string, onEvent:(payload:any)=>void});
        }

        export class SucceedOnListen extends Decorator {
            constructor(options:DecoratorOptions & {rule:string, getOptions:()=>behaviors.ListenBehaviorOptions, onResult:(listener:behaviors.ListenEmitter)=>void});
        }

        export class SucceedOnListenJs extends Decorator {
            constructor(options:DecoratorOptions & {getRule:()=>string, getOptions:()=>behaviors.ListenBehaviorOptions, onResult:(listener:behaviors.ListenEmitter)=>void});
        }

        export class TimeoutFail extends Decorator {
            constructor(options:DecoratorOptions & {timeout:number});
        }

        export class TimeoutSucceed extends Decorator {
            constructor(options:DecoratorOptions & {timeout:number});
        }

        export class TimeoutSucceedJs extends Decorator {
            constructor(options:DecoratorOptions & {getTime:()=>number});
        }

        export class WhileCondition extends Decorator {
            constructor(options:DecoratorOptions & {init?:()=>void, conditional:()=>boolean});
        }
        // endregion Decorator definitions
    }

    export const Blackboard: {};

    export function register(name:string, namespace:string, classRef:new (options:any)=>Behavior):void;
    export function create(uri:string|Function, overrides?:any):BehaviorTree;
    export function run(uri:string|Function, overrides?:any, onFinishedCallback?:(status:Status)=>void):BehaviorTree;
}

export default bt;