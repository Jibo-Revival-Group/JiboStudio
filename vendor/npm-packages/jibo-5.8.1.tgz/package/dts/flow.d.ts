import EventEmitter = require('jibo-eventemitter3');
import bt from './bt';

declare namespace flow {
    export class FlowExecutor {
        blackboard:any;
        emitter:EventEmitter;
        result:any;
        start():void;
        update():boolean;
        stop():Promise<void>;
        destroy():void;
    }
    
    export class ActivityImplementation {
        name:string;
        class:string;

        status:bt.Status;
        options:any;
        result:any;
        optionCodeThis:any;  // All user code supplied in Options has access to a 'this.' which is stored here.
        exceptionPayload:any; // if result starts with a ~, this is (potentially) the payload accompanying it.
        transitions:[any];
        exceptions:[any];
    }

    export function register(name:string, namespace:string, classRef:new (options:any)=>ActivityImplementation):void;
    export function create(uri:string|Function, overrides?:any):FlowExecutor;
    export function run(uri:string|Function, overrides?:any, onFinishedCallback?:(status)=>void):FlowExecutor;
}

export default flow;