import EventEmitter = require('jibo-eventemitter3');

declare class LoaderError {
    name: string;
    message: string;
    stack: string;
    originalError:any;
    request:string;
    toString():string;
}
declare class AssetUtils {
    static isPlain(obj:any):boolean;
}
declare type Callback = (err:Error, result?:any) => void;
declare class AssetLoad extends EventEmitter {
    id:number;
    mode:number;
    startAll:boolean;
    results:any;
    running:boolean;
    numLoaded:number;
    total:number;
    cacheAll:boolean|string;
    remoteAll:boolean;
    timeoutAll:number;
    cancel():void;
}

declare interface MultiOptions {
    complete?:Function;
    taskDone?:Function;
    progress?:Function;
    cacheAll?:boolean|string;
    startAll?:boolean;
    remoteAll?:boolean;
    timeoutAll?:number;
}

declare interface Asset {
    src:string;
    id?:string;
    complete?:Function;
    cache?:boolean|string;
    remote?:boolean;
    timeout?:number;
    format?:string;
    type?:string;
    root?:string;
    upload?:boolean;
}

declare class CacheItem {
    request:string;
    content:any;
    destroy(): void;
}

declare type Cache = {[id:string]: CacheItem};
declare type Caches = {[id:string]: Cache};

export default class LoaderPlugin {
    AssetUtils: typeof AssetUtils;
    LoaderError: typeof LoaderError;
    basePath:string;
    baseUrl:string;
    activeCache:string;
    load(source:string, complete:Function, progress?:Function, cache?:boolean|string, data?:any, remote?:boolean, timeout?:number, format?:string):AssetLoad;
    load(asset:Asset, complete?:Function):AssetLoad;
    load(assets:{[id:string]:Asset}, options?:MultiOptions|Function):AssetLoad;
    load(list:Asset[], options?:MultiOptions|Function):AssetLoad;
    unload(assets:any): LoaderPlugin;
    unloadFrom(assets:Asset|Asset[], cacheId?:string): LoaderPlugin;
    unloadAll(cacheId?:string): LoaderPlugin;
    cancelAll(): LoaderPlugin;
    addCache(cacheId:string): LoaderPlugin;
    defaultCache(): LoaderPlugin;
    deleteCache(cacheId:string): LoaderPlugin;
    cached(id:string, cacheId?:string):any;
    getCache(cacheId?:string): Cache;
    getCaches(): Caches;
}