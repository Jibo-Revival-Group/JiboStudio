
declare class Callsite {
    getFileName():string;
}

declare function callsite():Array<Callsite>;
declare module 'callsite' {
    export = callsite;
}
