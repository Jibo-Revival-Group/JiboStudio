
declare namespace GLOBAL {
    export var jibo:any;
}

declare module "module" {
    export function _resolveFilename(moduleId:string, opt:any):string;
    export function _nodeModulePaths(fromDir:string):string;
}

declare module "ipc" {
    import {EventEmitter} from 'events';
    class IPC extends EventEmitter {
        new();
        send(channel:string, ...args);
    }
    export = new IPC;
}

declare module "find-root" {
    function findRoot(dir?:string):string;
    export = findRoot;
}

declare module "uuid" {
    export function v4(): string;
}

declare module "jibo-background" {
    export var NotificationsService;
}

declare module "utils" {
    export var AnimationUtils, PathUtils, Timer, DelayedCall, perf;
}

declare module "jibo-keyframes" {
    export class conversion {
        static toPixelsX(meters:number):number;
        static toPixelsY(meters:number):number;
    }
}

declare module "hammerjs" {
    export var Manager:any;
    export var Pan:any;
    export var Swipe:any;
    export var DIRECTION_ALL:any;
    export var DIRECTION_RIGHT:any;
    export var DIRECTION_LEFT:any;
    export var DIRECTION_DOWN:any;
    export var DIRECTION_HORIZONTAL:any;
    export var DIRECTION_NONE:any;
    export default {};
}

declare module "eases" {
    export default {};
}

// https://github.com/feross/blob-to-buffer
declare module "blob-to-buffer" {
    function blobToBuffer(blob:Blob, cb:(err:Error, buffer:Buffer) => void): void;
    export = blobToBuffer;
}

declare module "expand-home-dir" {
    function expandHomeDir(path:string):string;
    export = expandHomeDir;
}