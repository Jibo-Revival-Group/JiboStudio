(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Container = PIXI.Container;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;

    lib.icon = Container.extend(function () {
        Container.call(this);

    });

    lib.border = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("SkillButtonBorder1"))
            .setTransform(-164.95, -149.95);
        this.addChild(instance1);
    });

    lib.gradient = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("SkillButtonGradient1"))
            .setTransform(-164.95, -149.95);
        this.addChild(instance1);
    });

    lib.background = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("SkillButtonBackground1"))
            .setTransform(-164.95, -149.95);
        this.addChild(instance1);
    });

    lib.content = Container.extend(function () {
        Container.call(this);
        var instance4 = this.background = new lib.background()
            .setTransform(0, -15);
        var instance3 = this.gradient = new lib.gradient()
            .setTransform(0, -15);
        var instance2 = this.border = new lib.border()
            .setTransform(0, -15);
        var instance1 = this.icon = new lib.icon()
            .setTransform(0, -16);
        this.addChild(instance4, instance3, instance2, instance1);
    });

    lib.skillButton = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.content()
            .setTransform(165, 165);
        this.addChild(instance1);
    });

    lib.skillButton.assets = {
        "SkillButtonBorder1": "images/SkillButtonBorder1.png",
        "SkillButtonGradient1": "images/SkillButtonGradient1.png",
        "SkillButtonBackground1": "images/SkillButtonBackground1.png"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.skillButton,
        background: 0x0,
        width: 330,
        height: 300,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}