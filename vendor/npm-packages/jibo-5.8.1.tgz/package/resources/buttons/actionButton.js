(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Container = PIXI.Container;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;

    lib.icon = Container.extend(function () {
        Container.call(this);

    });

    lib.border = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("ActionButtonBorder1"))
            .setTransform(-132.05, -132.05);
        this.addChild(instance1);
    });

    lib.gradient = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("ActionButtonGradient1"))
            .setTransform(-132.05, -132.05);
        this.addChild(instance1);
    });

    lib.background = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("ActionButtonBackground1"))
            .setTransform(-132.05, -132.05);
        this.addChild(instance1);
    });

    lib.content = Container.extend(function () {
        Container.call(this);
        var instance4 = this.background = new lib.background();
        var instance3 = this.gradient = new lib.gradient();
        var instance2 = this.border = new lib.border();
        var instance1 = this.icon = new lib.icon();
        this.addChild(instance4, instance3, instance2, instance1);
    });

    lib.actionButton = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.content()
            .setTransform(132, 132);
        this.addChild(instance1);
    });

    lib.actionButton.assets = {
        "ActionButtonBorder1": "images/ActionButtonBorder1.png",
        "ActionButtonGradient1": "images/ActionButtonGradient1.png",
        "ActionButtonBackground1": "images/ActionButtonBackground1.png"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.actionButton,
        background: 0x0,
        width: 264,
        height: 264,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}