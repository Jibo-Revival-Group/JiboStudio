(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Container = PIXI.Container;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;
    var Text = PIXI.Text;
    var Graphics = PIXI.Graphics;
    var shapes = PIXI.animate.ShapesCache;

    lib.videoIcon = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("videoIcon1"));
        this.addChild(instance1);
    });

    lib.contentOverlay = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("contentOverlay1"))
            .setTransform(-165, -165);
        this.addChild(instance1);
    });

    lib.target = Container.extend(function () {
        Container.call(this);

    });

    lib.albumUnderlay = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("albumUnderlay1"))
            .setTransform(-177.7, -177.7);
        this.addChild(instance1);
    });

    lib.contentButton_1 = Container.extend(function () {
        Container.call(this);
        var instance5 = new Graphics()
            .drawCommands(shapes.contentButton[0])
            .setRenderable(false)
            .setTransform(-6.8, -8.85);
        var instance7 = this.underlay = new lib.albumUnderlay()
            .setTransform(-0.05);
        var instance6 = this.target = new lib.target()
            .setTransform(-165, -165)
            .setMask(instance5);
        var instance4 = this.overlay = new lib.contentOverlay();
        var instance3 = this.albumLength = new Text("3")
            .setStyle({
                fontFamily: "Proxima Nova Soft",
                fontSize: 34,
                fontWeight: "bold",
                fill: "#0e0e0e"
            })
            .setAlign("center")
            .setTransform(136.2, 119.1);
        var instance2 = this.albumTitle = new Text("Album Title")
            .setStyle({
                fontFamily: "Proxima Nova Soft",
                fontSize: 75,
                fontWeight: "bold",
                fill: "#fff"
            })
            .setAlign("center")
            .setTransform(-1.1999999999999886, -73.4);
        var instance1 = this.videoIcon = new lib.videoIcon()
            .setTransform(-135, -135);
        this.addChild(instance5, instance7, instance6, instance4, instance3, instance2, instance1);
    });

    lib.contentButton = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.contentButton_1()
            .setTransform(165, 165);
        this.addChild(instance1);
    });

    lib.contentButton.assets = {
        "contentButton": "images/contentButton.shapes.json",
        "contentButton_atlas_1": "images/contentButton_atlas_1.json"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.contentButton,
        background: 0x0,
        width: 330,
        height: 330,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}