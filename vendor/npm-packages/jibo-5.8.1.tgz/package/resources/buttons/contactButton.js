(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Container = PIXI.Container;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;
    var Graphics = PIXI.Graphics;
    var shapes = PIXI.animate.ShapesCache;

    var Graphic1 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 15, loop: false });
        var instance1 = new Sprite(fromFrame("check-contact1"));
        var instance2 = new Sprite(fromFrame("check-contact3"));
        var instance3 = new Sprite(fromFrame("check-contact4"));
        var instance4 = new Sprite(fromFrame("check-contact5"));
        var instance5 = new Sprite(fromFrame("check-contact6"));
        var instance6 = new Sprite(fromFrame("check-contact7"));
        var instance7 = new Sprite(fromFrame("check-contact8"));
        var instance8 = new Sprite(fromFrame("check-contact10"));
        var instance9 = new Sprite(fromFrame("check-contact12"))
            .setTransform(120.8, 146.1);
        this.addTimedChild(instance1, 0, 2, {
                "0": {
                    x: 120.8,
                    y: 203.65
                }
            })
            .addTimedChild(instance2, 2, 1, {
                "2": {
                    x: 120.8,
                    y: 203.65
                }
            })
            .addTimedChild(instance3, 3, 1, {
                "3": {
                    x: 120.8,
                    y: 203.65
                }
            })
            .addTimedChild(instance4, 4, 1, {
                "4": {
                    x: 120.8,
                    y: 203.65
                }
            })
            .addTimedChild(instance5, 5, 1, {
                "5": {
                    x: 120.8,
                    y: 195.85
                }
            })
            .addTimedChild(instance6, 6, 1, {
                "6": {
                    x: 120.8,
                    y: 156.35
                }
            })
            .addTimedChild(instance7, 7, 2, {
                "7": {
                    x: 120.8,
                    y: 148.3
                }
            })
            .addTimedChild(instance8, 9, 2, {
                "9": {
                    x: 120.8,
                    y: 144.3
                }
            })
            .addTimedChild(instance9, 11, 4);
    });

    var Graphic2 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 15, loop: false });
        var instance1 = new Sprite(fromFrame("check-contact-close1"));
        var instance2 = new Sprite(fromFrame("check-contact-close3"));
        var instance3 = new Sprite(fromFrame("check-contact-close4"));
        var instance4 = new Sprite(fromFrame("check-contact-close5"));
        var instance5 = new Sprite(fromFrame("check-contact-close6"));
        var instance6 = new Sprite(fromFrame("check-contact-close7"));
        var instance7 = new Sprite(fromFrame("check-contact-close8"));
        var instance8 = new Sprite(fromFrame("check-contact-close9"));
        this.addTimedChild(instance1, 0, 2, {
                "0": {
                    x: 123,
                    y: 146.1
                }
            })
            .addTimedChild(instance2, 2, 1, {
                "2": {
                    x: 127.6,
                    y: 146.1
                }
            })
            .addTimedChild(instance3, 3, 1, {
                "3": {
                    x: 137.7,
                    y: 146.1
                }
            })
            .addTimedChild(instance4, 4, 1, {
                "4": {
                    x: 149.95,
                    y: 146.1
                }
            })
            .addTimedChild(instance5, 5, 1, {
                "5": {
                    x: 170.75,
                    y: 146.1
                }
            })
            .addTimedChild(instance6, 6, 1, {
                "6": {
                    x: 212.2,
                    y: 146.1
                }
            })
            .addTimedChild(instance7, 7, 1, {
                "7": {
                    x: 257.4,
                    y: 146.1
                }
            })
            .addTimedChild(instance8, 8, 2, {
                "8": {
                    x: 289.9,
                    y: 140.7
                }
            });
    });

    lib.check_gray = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("check-gray1"));
        this.addChild(instance1);
    });

    lib.check = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 31,
            labels: {
                check_open: 0,
                check_open_stop: 15,
                check_close: 16,
                check_close_stop: 30
            }
        });
        var instance1 = new lib.check_gray();
        var instance2 = new Graphic1(MovieClip.SYNCHED);
        var instance3 = new Graphic2(MovieClip.SYNCHED)
            .setTransform(-208.8, -216.8);
        this.addTimedChild(instance1, 0, 31, {
                "0": {
                    x: -165.05,
                    y: -165.05,
                    a: 0
                },
                "1": {
                    a: 0.07
                },
                "2": {
                    a: 0.15
                },
                "3": {
                    a: 0.23
                },
                "4": {
                    a: 0.3
                },
                "5": {
                    a: 0.38
                },
                "6": {
                    a: 0.45
                },
                "7": {
                    a: 0.53
                },
                "8": {
                    a: 0.6
                },
                "17": {
                    a: 0.53
                },
                "18": {
                    a: 0.45
                },
                "19": {
                    a: 0.38
                },
                "20": {
                    a: 0.3
                },
                "21": {
                    a: 0.23
                },
                "22": {
                    a: 0.15
                },
                "23": {
                    a: 0.07
                },
                "24": {
                    a: 0
                }
            })
            .addTimedChild(instance2, 1, 15, {
                "1": {
                    x: -208.8,
                    y: -216.8
                }
            })
            .addTimedChild(instance3, 16, 15);
    });

    lib.icon = Container.extend(function () {
        Container.call(this);

    });

    lib.border = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("border1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.gradient = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("gradient1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.background = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("background1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.content = Container.extend(function () {
        Container.call(this);
        var instance2 = new Graphics()
            .drawCommands(shapes.contactsButton[0])
            .setRenderable(false);
        var instance6 = this.background = new lib.background();
        var instance5 = this.gradient = new lib.gradient();
        var instance4 = this.border = new lib.border();
        var instance3 = this.icon = new lib.icon()
            .setMask(instance2);
        var instance1 = this.check = new lib.check();
        this.addChild(instance2, instance6, instance5, instance4, instance3, instance1);
    });

    lib.contactsButton = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.content()
            .setTransform(165.05, 165);
        this.addChild(instance1);
    });

    lib.contactsButton.assets = {
        "check-contact1": "images/check-contact1.png",
        "check-contact3": "images/check-contact3.png",
        "check-contact4": "images/check-contact4.png",
        "check-contact5": "images/check-contact5.png",
        "check-contact6": "images/check-contact6.png",
        "check-contact7": "images/check-contact7.png",
        "check-contact8": "images/check-contact8.png",
        "check-contact10": "images/check-contact10.png",
        "check-contact12": "images/check-contact12.png",
        "check-contact-close1": "images/check-contact-close1.png",
        "check-contact-close3": "images/check-contact-close3.png",
        "check-contact-close4": "images/check-contact-close4.png",
        "check-contact-close5": "images/check-contact-close5.png",
        "check-contact-close6": "images/check-contact-close6.png",
        "check-contact-close7": "images/check-contact-close7.png",
        "check-contact-close8": "images/check-contact-close8.png",
        "check-contact-close9": "images/check-contact-close9.png",
        "check-gray1": "images/check-gray1.png",
        "border1": "images/border1.png",
        "gradient1": "images/gradient1.png",
        "background1": "images/background1.png",
        "contactsButton": "images/contactsButton.shapes.json"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.contactsButton,
        background: 0x0,
        width: 330,
        height: 330,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}