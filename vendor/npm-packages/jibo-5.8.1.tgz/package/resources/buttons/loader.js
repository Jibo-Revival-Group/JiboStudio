(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;

    var Graphic1 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot3"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic2 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 2, loop: false });
        var instance1 = new Sprite(fromFrame("dot2"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic3 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 14, loop: false });
        var instance1 = new Sprite(fromFrame("dot2"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic4 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 21, loop: false });
        var instance1 = new Sprite(fromFrame("dot4"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic5 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 19, loop: false });
        var instance1 = new Sprite(fromFrame("dot3"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic6 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 23, loop: false });
        var instance1 = new Sprite(fromFrame("dot5"))
            .setTransform(-15.9, -15.25, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic7 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 14, loop: false });
        var instance1 = new Sprite(fromFrame("dot3"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic8 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot4"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic9 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot3"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic10 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 24, loop: false });
        var instance1 = new Sprite(fromFrame("dot2"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic11 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot1"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic12 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot1"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic13 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot1"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic14 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot1"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    var Graphic15 = MovieClip.extend(function (mode) {
        MovieClip.call(this, { mode: mode, duration: 26, loop: false });
        var instance1 = new Sprite(fromFrame("dot1"))
            .setTransform(-13.25, -13.2, 0.908, 0.908);
        this.addTimedChild(instance1);
    });

    lib.content = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 26
        });
        var instance9 = new Graphic15(MovieClip.SYNCHED)
            .setTransform(-0.3, 27.65, 0.734, 0.734);
        var instance8 = new Graphic14(MovieClip.SYNCHED)
            .setTransform(30, -1.35, 0.734, 0.734);
        var instance7 = new Graphic13(MovieClip.SYNCHED)
            .setTransform(-0.3, -1.35, 0.734, 0.734);
        var instance6 = new Graphic12(MovieClip.SYNCHED)
            .setTransform(-30.6, -1.35, 0.734, 0.734);
        var instance5 = new Graphic11(MovieClip.SYNCHED)
            .setTransform(-0.3, -29.35, 0.734, 0.734);
        var instance10 = new Graphic10(MovieClip.SYNCHED);
        var instance4 = new Graphic9(MovieClip.SYNCHED);
        var instance3 = new Graphic8(MovieClip.SYNCHED);
        var instance2 = new Graphic2(MovieClip.SYNCHED);
        var instance15 = new Graphic7(MovieClip.SYNCHED);
        var instance11 = new Graphic6(MovieClip.SYNCHED);
        var instance13 = new Graphic5(MovieClip.SYNCHED);
        var instance12 = new Graphic4(MovieClip.SYNCHED);
        var instance14 = new Graphic3(MovieClip.SYNCHED);
        var instance1 = new Graphic1(MovieClip.SYNCHED);
        this.addTimedChild(instance9)
            .addTimedChild(instance8)
            .addTimedChild(instance7)
            .addTimedChild(instance6)
            .addTimedChild(instance5)
            .addTimedChild(instance10, 2, 24, {
                "2": {
                    x: 30,
                    y: 27.65,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "3": {
                    a: 0.01
                },
                "4": {
                    a: 0.06
                },
                "5": {
                    a: 0.16
                },
                "6": {
                    a: 0.36
                },
                "7": {
                    a: 0.67
                },
                "8": {
                    a: 0.89
                },
                "9": {
                    a: 0.98
                },
                "10": {
                    a: 1
                },
                "11": {
                    a: 0.99
                },
                "12": {
                    a: 0.96
                },
                "13": {
                    a: 0.91
                },
                "14": {
                    a: 0.81
                },
                "15": {
                    a: 0.64
                },
                "16": {
                    a: 0.39
                },
                "17": {
                    a: 0.18
                },
                "18": {
                    a: 0.07
                },
                "19": {
                    a: 0.02
                },
                "20": {
                    a: 0
                }
            })
            .addTimedChild(instance4, 0, 26, {
                "0": {
                    x: -0.3,
                    y: 27.65,
                    sx: 0.734,
                    sy: 0.734,
                    a: 1
                },
                "1": {
                    a: 0.99
                },
                "2": {
                    a: 0.96
                },
                "3": {
                    a: 0.88
                },
                "4": {
                    a: 0.74
                },
                "5": {
                    a: 0.51
                },
                "6": {
                    a: 0.24
                },
                "7": {
                    a: 0.09
                },
                "8": {
                    a: 0.02
                },
                "9": {
                    a: 0
                },
                "20": {
                    a: 0.02
                },
                "21": {
                    a: 0.08
                },
                "22": {
                    a: 0.23
                },
                "23": {
                    a: 0.54
                },
                "24": {
                    a: 0.84
                },
                "25": {
                    a: 0.97
                }
            })
            .addTimedChild(instance3, 0, 26, {
                "0": {
                    x: -30.6,
                    y: 27.65,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "1": {
                    a: 0.01
                },
                "2": {
                    a: 0.06
                },
                "3": {
                    a: 0.16
                },
                "4": {
                    a: 0.36
                },
                "5": {
                    a: 0.67
                },
                "6": {
                    a: 0.89
                },
                "7": {
                    a: 0.98
                },
                "8": {
                    a: 1
                },
                "9": {
                    a: 0.98
                },
                "10": {
                    a: 0.92
                },
                "11": {
                    a: 0.77
                },
                "12": {
                    a: 0.46
                },
                "13": {
                    a: 0.16
                },
                "14": {
                    a: 0.03
                },
                "15": {
                    a: 0
                }
            })
            .addTimedChild(instance2, 0, 2, {
                "0": {
                    x: -0.3,
                    y: -29.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0.16
                },
                "1": {
                    a: 0
                }
            })
            .addTimedChild(instance15, 12, 14, {
                "12": {
                    x: 30,
                    y: -1.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "13": {
                    a: 0.01
                },
                "14": {
                    a: 0.06
                },
                "15": {
                    a: 0.16
                },
                "16": {
                    a: 0.36
                },
                "17": {
                    a: 0.67
                },
                "18": {
                    a: 0.89
                },
                "19": {
                    a: 0.98
                },
                "20": {
                    a: 1
                },
                "21": {
                    a: 0.98
                },
                "22": {
                    a: 0.88
                },
                "23": {
                    a: 0.64
                },
                "24": {
                    a: 0.24
                },
                "25": {
                    a: 0.04
                }
            })
            .addTimedChild(instance11, 3, 23, {
                "3": {
                    x: -0.3,
                    y: -1.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "4": {
                    a: 0.01
                },
                "5": {
                    a: 0.06
                },
                "6": {
                    a: 0.16
                },
                "7": {
                    a: 0.36
                },
                "8": {
                    a: 0.67
                },
                "9": {
                    a: 0.89
                },
                "10": {
                    a: 0.98
                },
                "11": {
                    a: 1
                },
                "12": {
                    a: 0.99
                },
                "13": {
                    a: 0.96
                },
                "14": {
                    a: 0.88
                },
                "15": {
                    a: 0.74
                },
                "16": {
                    a: 0.51
                },
                "17": {
                    a: 0.24
                },
                "18": {
                    a: 0.09
                },
                "19": {
                    a: 0.02
                },
                "20": {
                    a: 0
                }
            })
            .addTimedChild(instance13, 7, 19, {
                "7": {
                    x: -30.6,
                    y: -1.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "8": {
                    a: 0.02
                },
                "9": {
                    a: 0.08
                },
                "10": {
                    a: 0.23
                },
                "11": {
                    a: 0.54
                },
                "12": {
                    a: 0.84
                },
                "13": {
                    a: 0.97
                },
                "14": {
                    a: 1
                },
                "15": {
                    a: 0.99
                },
                "16": {
                    a: 0.97
                },
                "17": {
                    a: 0.93
                },
                "18": {
                    a: 0.85
                },
                "19": {
                    a: 0.73
                },
                "20": {
                    a: 0.53
                },
                "21": {
                    a: 0.3
                },
                "22": {
                    a: 0.14
                },
                "23": {
                    a: 0.05
                },
                "24": {
                    a: 0.01
                },
                "25": {
                    a: 0
                }
            })
            .addTimedChild(instance12, 5, 21, {
                "5": {
                    x: 30,
                    y: -29.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "6": {
                    a: 0.01
                },
                "7": {
                    a: 0.05
                },
                "8": {
                    a: 0.12
                },
                "9": {
                    a: 0.26
                },
                "10": {
                    a: 0.49
                },
                "11": {
                    a: 0.76
                },
                "12": {
                    a: 0.91
                },
                "13": {
                    a: 0.98
                },
                "14": {
                    a: 1
                },
                "15": {
                    a: 0.99
                },
                "16": {
                    a: 0.96
                },
                "17": {
                    a: 0.91
                },
                "18": {
                    a: 0.81
                },
                "19": {
                    a: 0.64
                },
                "20": {
                    a: 0.39
                },
                "21": {
                    a: 0.18
                },
                "22": {
                    a: 0.07
                },
                "23": {
                    a: 0.02
                },
                "24": {
                    a: 0
                }
            })
            .addTimedChild(instance14, 12, 14, {
                "12": {
                    x: -0.3,
                    y: -29.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 0
                },
                "13": {
                    a: 0.01
                },
                "14": {
                    a: 0.05
                },
                "15": {
                    a: 0.12
                },
                "16": {
                    a: 0.26
                },
                "17": {
                    a: 0.49
                },
                "18": {
                    a: 0.76
                },
                "19": {
                    a: 0.91
                },
                "20": {
                    a: 0.98
                },
                "21": {
                    a: 1
                },
                "22": {
                    a: 0.98
                },
                "23": {
                    a: 0.92
                },
                "24": {
                    a: 0.77
                },
                "25": {
                    a: 0.46
                }
            })
            .addTimedChild(instance1, 0, 26, {
                "0": {
                    x: -30.6,
                    y: -29.35,
                    sx: 0.734,
                    sy: 0.734,
                    a: 1
                },
                "1": {
                    a: 0.98
                },
                "2": {
                    a: 0.92
                },
                "3": {
                    a: 0.77
                },
                "4": {
                    a: 0.46
                },
                "5": {
                    a: 0.16
                },
                "6": {
                    a: 0.03
                },
                "7": {
                    a: 0
                },
                "22": {
                    a: 0.04
                },
                "23": {
                    a: 0.19
                },
                "24": {
                    a: 0.61
                },
                "25": {
                    a: 0.93
                }
            });
    });

    lib.loader = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.content()
            .setTransform(0, 0, 1.5, 1.5);
        this.addChild(instance1);
    });

    lib.loader.assets = {
        "loader_atlas_1": "images/loader_atlas_1.json"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.loader,
        background: 0x0,
        width: 1280,
        height: 720,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}