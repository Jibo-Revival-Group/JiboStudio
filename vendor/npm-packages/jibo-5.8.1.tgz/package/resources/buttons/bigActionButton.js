(function (PIXI, lib) {

    var MovieClip = PIXI.animate.MovieClip;
    var Container = PIXI.Container;
    var Sprite = PIXI.Sprite;
    var fromFrame = PIXI.Texture.fromFrame;

    lib.bigAction_icon = Container.extend(function () {
        Container.call(this);

    });

    lib.bigAction_border = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("bigAction_border1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.bigAction_gradient = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("bigAction_gradient1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.bigAction_background = Container.extend(function () {
        Container.call(this);
        var instance1 = new Sprite(fromFrame("bigAction_background1"))
            .setTransform(-165.05, -165.05);
        this.addChild(instance1);
    });

    lib.bigAction_content = Container.extend(function () {
        Container.call(this);
        var instance4 = this.background = new lib.bigAction_background();
        var instance3 = this.gradient = new lib.bigAction_gradient();
        var instance2 = this.border = new lib.bigAction_border();
        var instance1 = this.icon = new lib.bigAction_icon();
        this.addChild(instance4, instance3, instance2, instance1);
    });

    lib.bigActionButton = MovieClip.extend(function () {
        MovieClip.call(this, {
            duration: 1,
            framerate: 30
        });
        var instance1 = this.content = new lib.bigAction_content()
            .setTransform(165.05, 165);
        this.addChild(instance1);
    });

    lib.bigActionButton.assets = {
        "bigAction_border1": "images/bigAction_border1.png",
        "bigAction_gradient1": "images/bigAction_gradient1.png",
        "bigAction_background1": "images/bigAction_background1.png"
    };
})(PIXI, lib = lib || {});
var lib;
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        stage: lib.bigActionButton,
        background: 0x0,
        width: 330,
        height: 330,
        framerate: 30,
        totalFrames: 1,
        library: lib
    };
}