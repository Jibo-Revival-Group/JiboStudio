/// <reference path="globals/lodash/index.d.ts" />

declare module "lodash/lodash.min" {
    import _ = require("lodash");
    export = _;
}