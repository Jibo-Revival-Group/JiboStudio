declare module "jibo-sync" {
    interface SyncOptions {
        url:string,
        dir:string,
        verbose?:boolean,
        close?:boolean,
        force?:boolean
    }
    export function uploadToServer(options:SyncOptions, callback:(error:any, msg?:string)=>void):void;
    export function closeServer(syncUrl, callback:(error:any, msg?:string) => void):void;
    export function stop():void;
}