(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.client = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Simple set of UI component dimensions that shared across various UI layout
 * calculations
 */
exports.default = {
    SCREEN_WIDTH: 1280,
    SCREEN_HEIGHT: 720,
    SCREEN_EPSILON: 2,
    CHAT_WIDTH: 400
};

},{}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Sychronizes html to the robots 3D visualization
 *
 * Based on this article and demo
 * http://math.stackexchange.com/questions/296794/finding-the-transform-matrix-from-4-projected-points-with-javascript
 * http://jsfiddle.net/dFrHS/1/
 */
// import lps from './services/lps-service';
const electron_1 = require("electron");
const animation_utilities_1 = require("animation-utilities");
const dimensions_1 = require("./dimensions");
const React = require("react");
const toolbar_1 = require("./views/toolbar");
const skills_service_manager_1 = require("skills-service-manager");
let camerasViews = {
    'viewFront': {
        'position': new animation_utilities_1.THREE.Vector3(0.5, 0, 0.35),
        'lookat': new animation_utilities_1.THREE.Vector3(0, 0, 0.15),
        'fov': 45
    },
    'viewTop': {
        'position': new animation_utilities_1.THREE.Vector3(0, 0, 1),
        'lookat': new animation_utilities_1.THREE.Vector3(0, 0, 0.15),
        'fov': 45
    },
    'viewReset': {
        'position': new animation_utilities_1.THREE.Vector3(0.5, 0, 0.35),
        'lookat': new animation_utilities_1.THREE.Vector3(0, 0, 0.15),
        'fov': 45
    }
};
let projectPlane = {
    'viewFront': { x: 1, y: 1, z: 0 },
    'viewTop': { x: 1, y: 1, z: 0 },
    'viewReset': { x: 1, y: 1, z: 0 }
};
let debugMode = false, cornerElements = [], settings;
exports.default = {
    init: function (robotInfo, createRobotRenderer, container, face, visualizer, onSettingsChangedCB, cb) {
        this.face = face;
        this.container = container;
        this.faceContent = document.getElementById('faceContent');
        this.selectedPlane = projectPlane['viewFront'];
        this.sidebar = document.getElementById('sidebar');
        // Remember the original page title, we'll be using the page title to communicate the current
        // zoom level
        this.pageTitle = document.title;
        settings = JSON.parse(electron_1.ipcRenderer.sendSync('get-simulator-settings'));
        this.sidebar.className = this.container.className = 'view' + settings.viewMode + " loading";
        // Make the container visualizer container as big as the full screen if that's where we're going
        if (settings.viewMode === '3d') {
            visualizer.style.width = window.innerWidth + 'px';
            visualizer.style.height = window.innerHeight + 'px';
        }
        // Ensure the body at least has a cursor when in the simulator
        if (!document.body.style.cursor) {
            document.body.style.cursor = "default";
        }
        this.initializeToolbar();
        // Always create a full 3d body renderer. We just hide it when we're in 2D mode
        createRobotRenderer(robotInfo, visualizer, animation_utilities_1.visualize.DisplayType.BODY, (robotRenderer) => {
            this.robotRenderer = robotRenderer;
            // Don't display anything until all UI is ready
            // visualizer.style.display = "none";
            // this.face.style.display = "none";
            this.container.className += "loading";
            // this.face.style.position = "absolute";
            // this.face.style.overflow = "hidden";
            //
            let mouseEvents = [
                "movedown",
                "mousemove",
                "mouseup",
                "mousewheel"
            ], modifierKeys = [
                "shiftKey",
                "ctrlKey",
                "altKey",
                "metaKey"
            ];
            mouseEvents.forEach((eventName) => {
                document.addEventListener(eventName, (event) => {
                    // If any of the modifier keys are down, then make the event
                    // go to the visualizer and it's camera controller
                    for (let i = 0; i < modifierKeys.length; i++) {
                        if (event[modifierKeys[i]]) {
                            this.robotRenderer.scene._container.style.pointerEvents = "all";
                            this.face.style.pointerEvents = "none";
                            return;
                        }
                    }
                    // If we made it here, the modifier key wasn't held, all events then
                    // go to the face elements
                    this.robotRenderer.scene._container.style.pointerEvents = "none";
                    this.face.style.pointerEvents = "all";
                });
            });
            if (debugMode) {
                let colors = [
                    'red',
                    'green',
                    'purple',
                    'blue'
                ];
                for (let i = 0; i < 4; i++) {
                    cornerElements.push(document.createElement('div'));
                    cornerElements[i].style.position = 'absolute';
                    cornerElements[i].style.width = "5px";
                    cornerElements[i].style.height = "5px";
                    cornerElements[i].style.background = colors[i];
                    if (document.body.firstChild) {
                        document.body.insertBefore(cornerElements[i], document.body.firstChild);
                    }
                    else {
                        document.body.appendChild(cornerElements[i]);
                    }
                }
            }
            this.robotRenderer.scene._postRenderCallbacks.push(() => {
                // Do nothing when in 3D mode
                if (settings.viewMode !== '3d') {
                    return;
                }
                let screenObject = this.robotRenderer.scene._scene.children[4].children[0].children[1].children[1].children[0].children[2].children[0], camera = this.robotRenderer.scene._camera, corners2d = getScreenPositions(animation_utilities_1.THREE, screenObject, camera);
                // debugger;
                if (debugMode) {
                    for (let i = 0; i < cornerElements.length; i++) {
                        cornerElements[i].style.marginLeft = Math.floor(corners2d[i].x) + 'px';
                        cornerElements[i].style.marginTop = Math.floor(corners2d[i].y) + 'px';
                    }
                }
                computeTransform([
                    corners2d[0].x, corners2d[0].y,
                    corners2d[1].x, corners2d[1].y,
                    corners2d[2].x, corners2d[2].y,
                    corners2d[3].x, corners2d[3].y
                ], this.face);
                // Make the UI elements invisible if the screen is facing away from the camera
                // TODO: Double check that this handles the case of the screen being way behind the camera
                this.face.style.zIndex = shouldBackFaceCull(corners2d) ? "-1" : "0";
            });
            // don't do document, instead container
            let container = document.getElementById('container');
            // gets all background but also gets face -- gotta fix that.
            container.addEventListener("mousedown", (evt) => {
                let coordinates = this.getClicked3DPoint(evt);
                if (this.mode === 'audio') {
                    evt.stopPropagation();
                    evt.preventDefault();
                    skills_service_manager_1.LPSService.instance.triggerAudioEvent(coordinates);
                }
            });
            container.addEventListener("mouseup", () => {
                if (this.mode === 'audio') {
                    skills_service_manager_1.LPSService.instance.triggerAudioEventEnd();
                }
            });
            // Don't display anything until all UI is ready
            this.container.className = this.container.className.replace('loading', '');
            let onViewModeChange = () => {
                // this.face.parentNode.style.width = (window.innerWidth - dims.CHAT_WIDTH) + "px";
                // this.face.parentNode.style.height = (window.innerHeight) + "px";
                this.face.style.transformOrigin = "0 0";
                if (settings.viewMode === '2d') {
                    // Clear perspective tranforms of any previous 3D manipulation
                    this.faceContent.style.transform = `scale(1.0)`;
                    //this.face.style.border = "thin solid rgb(80, 80, 80)";
                    this.face.style.width = (dimensions_1.default.SCREEN_WIDTH + 2) + "px";
                    this.face.style.height = (dimensions_1.default.SCREEN_HEIGHT + 2) + "px";
                    // this.face.style.width = this.container.clientWidth + "px";
                    // this.face.style.height = this.container.clientHeight + "px";
                    this.face.style.top = undefined;
                    this.face.style.left = undefined;
                    this.face.style.position = "absolute";
                    visualizer.style.position = "absolute";
                    this.hideToolbar();
                }
                else {
                    this.face.style.marginLeft = "0px";
                    this.face.style.marginTop = "0px";
                    // We add one pixel to the size as it seems to not cut off the
                    // the last pixel on the right/top of the container
                    //this.face.style.border = "none";
                    this.face.style.width = (dimensions_1.default.SCREEN_WIDTH + dimensions_1.default.SCREEN_EPSILON) + "px";
                    this.face.style.height = (dimensions_1.default.SCREEN_HEIGHT + dimensions_1.default.SCREEN_EPSILON) + "px";
                    // this.face.style.width = this.container.clientWidth + "px";
                    // this.face.style.height = this.container.clientHeight + "px";
                    this.face.style.top = "0px";
                    this.face.style.left = "0px";
                    this.robotRenderer.setBackgroundColor(0.25, 0.25, 0.25, 1.0);
                    this.robotRenderer.setGrid(0.05, 6, new animation_utilities_1.THREE.Color("rgb(128, 128, 128)"));
                    this.robotRenderer.scene._camera.near = 0.001;
                    this.robotRenderer.scene._camera.updateProjectionMatrix();
                    this.showToolbar();
                }
            };
            let onDimensionChanges = () => {
                let effectiveZoom = settings.zoomFactor * settings.devicePixelRatio;
                // this.face.parentNode.style.width = (window.innerWidth - dims.CHAT_WIDTH) + "px";
                // this.face.parentNode.style.height = (window.innerHeight) + "px";
                //webframe.setZoomFactor(1.0/settings.devicePixelRatio);
                if (settings.viewMode === '2d') {
                    this.sidebar.className = this.container.className = 'view2d';
                    //webframe.setZoomFactor(settings.zoomFactor);
                    this.faceContent.style.transform = `scale(${settings.zoomFactor})`;
                    // Make sure the face visualization is centered if the zoom
                    let effectiveWidth = dimensions_1.default.SCREEN_WIDTH * settings.zoomFactor, effectiveHeight = dimensions_1.default.SCREEN_HEIGHT * settings.zoomFactor;
                    // If there needs to be some centering
                    // Horizontally
                    if (effectiveWidth < window.innerWidth) {
                        this.face.style.marginLeft = Math.floor((window.innerWidth - dimensions_1.default.CHAT_WIDTH - effectiveWidth) / 2.0) + "px";
                    }
                    else {
                        this.face.style.marginLeft = "0px";
                    }
                    // Vertically
                    if (effectiveHeight < window.innerHeight) {
                        this.face.style.marginTop = Math.floor((window.innerHeight - effectiveHeight) / 2.0) + "px";
                    }
                    else {
                        this.face.style.marginTop = "0px";
                    }
                    document.title = `${this.pageTitle} (${Math.floor(effectiveZoom * 100)}%)`;
                }
                else {
                    this.sidebar.className = this.container.className = 'view3d';
                    this.faceContent.style.transform = `scale(1.0)`;
                    visualizer.style.width = (window.innerWidth - dimensions_1.default.CHAT_WIDTH) + "px";
                    visualizer.style.height = window.innerHeight + 'px';
                    // visualizer.style.width = this.container.clientWidth + "px";
                    // visualizer.style.height = this.container.clientHeight + 'px';
                    // visualizer.style.display = "block";
                    this.robotRenderer.scene.handleResize();
                    document.title = `${this.pageTitle} (3D)`;
                }
            };
            // The main process notifies us when simulator settings change
            electron_1.ipcRenderer.on('simulator-settings-changed', (sender, _settings) => {
                let previous = settings;
                settings = JSON.parse(_settings);
                onSettingsChangedCB(previous, settings);
                // Check if the viewMode has changed
                if (previous.viewMode !== settings.viewMode) {
                    onViewModeChange();
                }
                onDimensionChanges();
            });
            const win = window;
            win.onDimensionChanges = onDimensionChanges;
            win.onViewModeChange = onViewModeChange;
            window.addEventListener('resize', () => {
                onDimensionChanges();
            });
            // Call these both once to get things initially set
            onViewModeChange();
            onDimensionChanges();
            cb(null, robotRenderer, settings, onDimensionChanges);
        });
    },
    initializeToolbar: function () {
        let toolbar = document.getElementById('toolbar');
        React.render(React.createElement(toolbar_1.default, { setMode: this.setMode.bind(this), setCamera: this.setCamera.bind(this) }), toolbar);
    },
    hideToolbar: function () {
        document.getElementById('toolbar').className += " hide";
    },
    showToolbar: function () {
        let toolbar = document.getElementById('toolbar');
        toolbar.className = toolbar.className.replace('hide', '');
    },
    setCamera: function (value) {
        // reset angles
        this.robotRenderer.scene._controls.reset();
        let cameraView = camerasViews[value];
        this.selectedPlane = projectPlane[value];
        this.robotRenderer.setCamera(cameraView.position, cameraView.lookat, cameraView.fov);
    },
    // TODO: update these planes that project
    getClicked3DPoint: function (event) {
        let visualizer = document.getElementById("visualizer");
        let camera = this.robotRenderer.scene.getCamera();
        let coordinates = animation_utilities_1.MouseCoordinateWrangler.unprojectEventToPlane(event, visualizer, camera, this.selectedPlane, { x: 0, y: 0, z: 1 });
        return coordinates;
    },
    setMode(mode) {
        this.mode = mode;
    }
};
function shouldBackFaceCull(corners2d) {
    let signedArea = 0, x1, y1, x2, y2;
    // This code expects things clockwise, computeTransform() expected them in TL, TR, BL, BR
    // order, but it's done with them for now, so we swamp them to make it right
    let tmp = corners2d[2];
    corners2d[2] = corners2d[3];
    corners2d[3] = tmp;
    for (let i = 0; i < corners2d.length; i++) {
        x1 = corners2d[i].x;
        y1 = corners2d[i].y;
        if (i === (corners2d.length - 1)) {
            x2 = corners2d[0].x;
            y2 = corners2d[0].y;
        }
        else {
            x2 = corners2d[i + 1].x;
            y2 = corners2d[i + 1].y;
        }
        signedArea += (x1 * y2 - x2 * y1);
    }
    // If the signed area is negative, then we should backface cull the screen elements
    return signedArea < 0;
}
function getScreenPositions(THREE, obj, camera) {
    let widthHalf = 0.5 * (window.innerWidth - dimensions_1.default.CHAT_WIDTH);
    let heightHalf = 0.5 * (window.innerHeight);
    obj.updateMatrixWorld();
    if (!obj.geometry.boundingBox) {
        obj.geometry.computeBoundingBox();
    }
    let corners3d = [
        // TL
        new THREE.Vector3(obj.geometry.boundingBox.max.x, obj.geometry.boundingBox.max.y, obj.geometry.boundingBox.max.z),
        // TR
        new THREE.Vector3(obj.geometry.boundingBox.min.x, obj.geometry.boundingBox.max.y, obj.geometry.boundingBox.max.z),
        // BL
        new THREE.Vector3(obj.geometry.boundingBox.max.x, obj.geometry.boundingBox.min.y, obj.geometry.boundingBox.min.z),
        // BR
        new THREE.Vector3(obj.geometry.boundingBox.min.x, obj.geometry.boundingBox.min.y, obj.geometry.boundingBox.min.z)
    ];
    let vector, corners2d = [];
    for (let i = 0; i < corners3d.length; i++) {
        vector = corners3d[i].applyMatrix4(obj.matrixWorld);
        vector.project(camera);
        vector.x = (vector.x * widthHalf) + widthHalf;
        vector.y = -(vector.y * heightHalf) + heightHalf;
        corners2d.push({
            x: Math.floor(vector.x),
            y: Math.floor(vector.y)
        });
    }
    return corners2d;
}
/*function printChildren(parent, indentLevel){
    console.log(indentLevel + parent.name);
    for(let i = 0; i<parent.children.length; i++){
        printChildren(parent.children[i], indentLevel + indent);
    }
}*/
function adj(m) {
    return [
        m[4] * m[8] - m[5] * m[7], m[2] * m[7] - m[1] * m[8], m[1] * m[5] - m[2] * m[4],
        m[5] * m[6] - m[3] * m[8], m[0] * m[8] - m[2] * m[6], m[2] * m[3] - m[0] * m[5],
        m[3] * m[7] - m[4] * m[6], m[1] * m[6] - m[0] * m[7], m[0] * m[4] - m[1] * m[3]
    ];
}
function multmm(a, b) {
    let c = Array(9);
    for (let i = 0; i != 3; ++i) {
        for (let j = 0; j != 3; ++j) {
            let cij = 0;
            for (let k = 0; k != 3; ++k) {
                cij += a[3 * i + k] * b[3 * k + j];
            }
            c[3 * i + j] = cij;
        }
    }
    return c;
}
function multmv(m, v) {
    return [
        m[0] * v[0] + m[1] * v[1] + m[2] * v[2],
        m[3] * v[0] + m[4] * v[1] + m[5] * v[2],
        m[6] * v[0] + m[7] * v[1] + m[8] * v[2]
    ];
}
/*function pdbg(m, v) {
  let r = multmv(m, v);
  return r + " (" + r[0]/r[2] + ", " + r[1]/r[2] + ")";
}*/
function basisToPoints(x1, y1, x2, y2, x3, y3, x4, y4) {
    let m = [
        x1, x2, x3,
        y1, y2, y3,
        1, 1, 1
    ];
    let v = multmv(adj(m), [x4, y4, 1]);
    return multmm(m, [
        v[0], 0, 0,
        0, v[1], 0,
        0, 0, v[2]
    ]);
}
function general2DProjection(x1s, y1s, x1d, y1d, x2s, y2s, x2d, y2d, x3s, y3s, x3d, y3d, x4s, y4s, x4d, y4d) {
    let s = basisToPoints(x1s, y1s, x2s, y2s, x3s, y3s, x4s, y4s);
    let d = basisToPoints(x1d, y1d, x2d, y2d, x3d, y3d, x4d, y4d);
    return multmm(d, adj(s));
}
/*function project(m, x, y) {
  let v = multmv(m, [x, y, 1]);
  return [v[0]/v[2], v[1]/v[2]];
}*/
function transform2d(elt, x1, y1, x2, y2, x3, y3, x4, y4) {
    let w = elt.offsetWidth - dimensions_1.default.SCREEN_EPSILON, h = elt.offsetHeight - dimensions_1.default.SCREEN_EPSILON;
    let t = general2DProjection(0, 0, x1, y1, w, 0, x2, y2, 0, h, x3, y3, w, h, x4, y4);
    for (let i = 0; i != 9; ++i)
        t[i] = t[i] / t[8];
    t = [t[0], t[3], 0, t[6],
        t[1], t[4], 0, t[7],
        0, 0, 1, 0,
        t[2], t[5], 0, t[8]];
    t = "matrix3d(" + t.join(", ") + ")";
    elt.style["-webkit-transform"] = t;
    elt.style["-moz-transform"] = t;
    elt.style["-o-transform"] = t;
    elt.style.transform = t;
}
function computeTransform(corners, element) {
    transform2d(element, corners[0], corners[1], corners[2], corners[3], corners[4], corners[5], corners[6], corners[7]);
}

},{"./dimensions":1,"./views/toolbar":13,"animation-utilities":undefined,"electron":undefined,"react":undefined,"skills-service-manager":undefined}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.default = React.createClass({
    getInitialState() {
        return {
            activeTab: 0
        };
    },
    render() {
        let tabs = [];
        this.props.tabs.forEach((tab, i) => {
            let className = 'main';
            if (i === this.state.activeTab) {
                className += ' selected';
            }
            tabs.push(React.createElement("button", { key: tab.id, id: tab.id, onClick: this.onClick.bind(this, i, tab.callback), className: className },
                React.createElement("span", { className: tab.icon, title: tab.label })));
        });
        return React.createElement("div", { className: 'tools', id: "tabBar" }, tabs);
    },
    onClick(i, cb) {
        this.state.activeTab = i;
        this.setState(this.state);
        cb();
    }
});

},{"react":undefined}],4:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const marked = require("marked");
const skills_service_manager_1 = require("skills-service-manager");
const path = require("path");
let targetIndexCount = 0;
exports.default = React.createClass({
    getInitialState() {
        return {
            isSelected: false
        };
    },
    componentDidMount() {
    },
    showEntities() {
    },
    // opType is "backup" or "restore"
    backupOrRestore(opType) {
        console.log("carrying out operation: ", opType);
        skills_service_manager_1.RegistryClient.instance.getRecordByName('system-manager', (error, record) => {
            let opFolder = path.join(process.env.HOME || process.env.USERPROFILE, '.jibo', 'backup', record.name);
            console.log("folder for ", opFolder);
            // On Robot:
            // /opt/tmp/backup/<name of service>
            // http://<service address>/_M_/system/backup/
            //
            //let serviceName:string = "/opt/tmp/backup/" + record.name;
            let data = { 'directory': opFolder };
            const request = new XMLHttpRequest();
            let postString = '/system/' + opType;
            request.open('POST', `http://${record.host}:${record.port}${postString}`, true);
            request.setRequestHeader('Content-Type', 'application/json');
            request.onreadystatechange = () => {
                if (request.readyState === 4) {
                    if (request.status === 204) {
                        console.log("POST request successful");
                    }
                    else {
                        console.log("POST request failed");
                    }
                }
            };
            request.send(JSON.stringify(data));
        });
    },
    doBackup() {
        console.log("Doing backup!");
        this.backupOrRestore("backup");
    },
    doRestore() {
        console.log("Doing restore!");
        this.backupOrRestore("restore");
    },
    doWipe() {
        console.log("Doing wipe!");
        this.backupOrRestore("wipe");
    },
    render() {
        let paneClassName = 'advanced-pane side-pane';
        if (!this.props.isSelected) {
            paneClassName += ' hidden';
        }
        let markdown = "Backup Jibo to Cloud.\n\n";
        const labelStyle = {
            paddingBottom: '8pt',
            paddingTop: '8pt'
        };
        let showEntities = null;
        return React.createElement("div", { className: paneClassName, ref: "rightPane" },
            React.createElement("div", { className: "panel-heading" },
                React.createElement("h2", { className: "target-heading" }, "Advanced Options")),
            React.createElement("div", { className: "instructions", dangerouslySetInnerHTML: {
                    __html: marked(markdown, { sanitize: true })
                } }),
            React.createElement("label", { style: { labelStyle } }, "Backup"),
            React.createElement("button", { className: "btn", onClick: this.doBackup }, "Do Backup"),
            React.createElement("label", { style: { labelStyle } }, "Restore"),
            React.createElement("button", { className: "btn", onClick: this.doRestore }, "Do Restore"),
            React.createElement("label", { style: { labelStyle } }, "Wipe"),
            React.createElement("button", { className: "btn", onClick: this.doWipe }, "Do Wipe"));
    }
});

},{"marked":undefined,"path":undefined,"react":undefined,"skills-service-manager":undefined}],5:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const electron_1 = require("electron");
const skills_service_manager_1 = require("skills-service-manager");
exports.default = React.createClass({
    getInitialState() {
        const speakerToId = {};
        this.props.loop.forEach((member) => {
            if (member.data.firstName) {
                speakerToId[member.data.firstName] = member.data.id;
            }
        });
        return {
            text: "",
            speaker: this.props.speakerId,
            speakerToId,
        };
    },
    componentDidMount() {
        skills_service_manager_1.TTSService.instance.setMode(this.props.ttsMode);
        this.inputStack = [""];
        this.inputIndex = 1;
    },
    onKeyDown(event) {
        let value = event.target.value;
        let keyCode = event.nativeEvent.keyCode;
        value = value.trim().replace(/[\|&;\$%@"#<>\(\)\+,?.]/g, "");
        if (keyCode === 13) {
            // carriage return
            this.saveInputText(value);
            this.setState({
                text: ""
            });
            this.props.onWords({ words: value, final: true, speaker: this.state.speaker, speakerId: this.state.speakerId });
            this.props.messageHandler({ words: value, speaker: this.state.speaker, speakerId: this.state.speakerId });
        }
        else if (keyCode === 32) {
            // space bar
            // send incremental result at each space.
            this.props.onWords({ words: value, incremental: true, speaker: this.state.speaker, speakerId: this.state.speakerId });
        }
        else if (keyCode === 38 && this.inputIndex > 1) {
            this.inputIndex -= 1;
            this.setState({
                text: this.inputStack[this.inputIndex]
            });
        }
        else if (keyCode === 40 && this.inputIndex < this.inputStack.length) {
            this.inputIndex += 1;
            this.setState({
                text: this.inputStack[this.inputIndex]
            });
        }
    },
    // adds a new entry to undo/redo of tts stack
    // potentially very big...
    // TODO: profile this?
    saveInputText(text) {
        if (text !== this.inputStack[this.inputStack.length - 1]) {
            this.inputStack.push(text);
        }
        this.inputIndex = this.inputStack.length;
    },
    onSpeakerChange(event) {
        let name = event.target.value;
        let id = this.state.speakerToId[name];
        electron_1.ipcRenderer.send('set-speaker-id', id);
        this.setState({
            speaker: name,
            speakerId: id,
        });
    },
    setTtsMode(mode) {
        if (this.state.ttsMode === mode) {
            return;
        }
        skills_service_manager_1.TTSService.instance.setMode(mode);
        electron_1.ipcRenderer.send('set-tts-mode', mode);
    },
    setTtsModeInstant() {
        this.setTtsMode('Instant');
    },
    setTtsModeIncremental() {
        this.setTtsMode('Incremental');
    },
    onChange(event) {
        let value = event.target.value;
        let textValue = value;
        value = value.trim().replace(/[\|&;\$%@"#<>\(\)\+,?.]/g, "").toLowerCase();
        this.setState({
            text: textValue
        });
    },
    render() {
        const speakers = [React.createElement("option", { value: '' }, "No ID")];
        this.props.loop.forEach((member) => {
            if (member.data.firstName) {
                if (this.state.speaker === member.data.memberId) {
                    speakers.push(React.createElement("option", { selected: true, value: member.data.memberId }, member.data.firstName));
                }
                else {
                    speakers.push(React.createElement("option", { value: member.data.memberId }, member.data.firstName));
                }
            }
        });
        return React.createElement("div", { className: "asr-input" },
            React.createElement("span", { className: "fa fa-comment chat-icon icon" }),
            React.createElement("input", { type: "text", className: "text text-lg chat-input", placeholder: "Speak to Jibo here...", value: this.state.text, onChange: this.onChange, onKeyDown: this.onKeyDown }),
            React.createElement("div", { className: "speaker row" },
                React.createElement("div", { className: "row-label" }, "Speaker"),
                React.createElement("div", { className: "row-content" },
                    React.createElement("select", { name: "Speaker", className: "text text-md speaker-input", onChange: this.onSpeakerChange }, speakers))),
            React.createElement("div", { className: "tts-mode row" },
                React.createElement("div", { className: "row-label" }, "TTS Mode"),
                React.createElement("div", { className: "row-content" },
                    React.createElement("label", { htmlFor: "dev" },
                        React.createElement("input", { type: "radio", value: "Instant", id: "instant", className: "radio", checked: this.props.ttsMode === "Instant", onChange: this.setTtsModeInstant }),
                        "Instant"),
                    React.createElement("label", { htmlFor: "incremental" },
                        React.createElement("input", { type: "radio", value: "Incremental", id: "incremental", className: "radio", checked: this.props.ttsMode === "Incremental", onChange: this.setTtsModeIncremental }),
                        "Incremental"))));
    }
});

},{"electron":undefined,"react":undefined,"skills-service-manager":undefined}],6:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const animation_utilities_1 = require("animation-utilities");
class AudioEvent {
    constructor(scene, position, name) {
        this.scene = scene;
        this.ts = [0, 0];
        this.type = undefined;
        this.name = name;
        this.position = {
            x: position.x,
            y: position.x,
            z: position.x
        },
            this.confidence = 100;
        let geometry = new animation_utilities_1.THREE.SphereGeometry(0.1, 32, 32);
        let material = new animation_utilities_1.THREE.MeshBasicMaterial({ color: 0xff0000, transparent: true, opacity: 1 });
        let sphere = new animation_utilities_1.THREE.Mesh(geometry, material);
        sphere.name = name;
        sphere.position.x = position.x;
        sphere.position.y = position.y;
        sphere.position.z = position.z;
        this.sphere = sphere;
        scene.add(sphere);
    }
    /*
     *  starts downscaling sphere
     *  calls callback when sphere is at scale 0
     *  and automatically removes from scene.
     */
    startScaling(cb) {
        this.cb = cb;
        this.sphereScale = 1;
        this.scale = setInterval(this._downScale.bind(this), 100);
    }
    /*
     *  Downscales sphere at rate of -0.05 per call,
     *  stops when scale = 0 and returns to callback.
     *  Should only ever be called by startScaling
     */
    _downScale() {
        this.sphereScale -= 0.05;
        if (this.sphereScale <= 0) {
            this.removeFromScene();
            clearInterval(this.scale);
            this.cb();
        }
        else {
            this.sphere.scale.x = this.sphereScale;
            this.sphere.scale.y = this.sphereScale;
            this.sphere.scale.z = this.sphereScale;
        }
    }
    /*
     * @param hex {hex} the hex code for the color to set sphere
     */
    setColor(hex) {
        this.sphere.material.color.setHex(hex);
    }
    /*
     * @param value {value} the value (0-1) for the opacity to set sphere
     */
    setOpacity(value) {
        this.sphere.material.opacity = value;
    }
    /*
     * @param name {name} the name to set sphere
     */
    setName(name) {
        this.name = name;
    }
    /*
     * @param type {type} the type to set sphere
     */
    updateType(type) {
        this.type = type;
    }
    /*
     * @param confidence {confidence} the confidence to set sphere
     */
    updateConfidence(confidence) {
        this.confidence = confidence;
    }
    /*
     * @param timestamp {timestamp} the timestamp to set sphere
     */
    updateTs(ts) {
        this.ts = ts;
    }
    /*
     * @returns id of audio event
     */
    getId() {
        return this.id;
    }
    /*
     * Removes the audio event from the scene, but does not delete
     */
    removeFromScene() {
        let me = this.scene.getObjectByName(this.name);
        if (me) {
            this.scene.remove(me);
        }
    }
}
exports.default = AudioEvent;

},{"animation-utilities":undefined}],7:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.default = React.createClass({
    getInitialState() {
        return {};
    },
    render() {
        let wrapperClass = 'message-wrapper fade-in';
        let author = '';
        if (this.props.message.author === 'jibo') {
            wrapperClass += ' jibo';
        }
        else if (this.props.message.author) {
            author = React.createElement("div", { className: "message-speaker" }, this.props.message.author);
        }
        if (this.props.message.break) {
            return React.createElement("div", { className: "message-session" });
        }
        return React.createElement("div", { className: wrapperClass },
            author,
            React.createElement("div", { className: 'message-bubble' },
                React.createElement("div", { className: "message-content" }, this.props.message.content)));
    }
});

},{"react":undefined}],8:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const skills_service_manager_1 = require("skills-service-manager");
const messages_list_1 = require("./messages-list");
const asr_view_1 = require("./asr-view");
exports.default = React.createClass({
    getInitialState() {
        return {
            isSelected: false
        };
    },
    componentDidMount() {
        this.chatProxy = this.props.chatProxy;
        skills_service_manager_1.TTSService.instance.on('speech', (text) => {
            this.messageHandler({ words: text, speaker: 'jibo' });
        });
        skills_service_manager_1.TTSService.instance.on('token', (text) => {
            this.incrementalMessageHandler(text);
        });
        // TODO: update this to not act differently in service based on mode!!!
        skills_service_manager_1.TTSService.instance.on('sending-tokens', () => {
            this.addMessage({
                content: '',
                author: 'jibo'
            });
        });
        skills_service_manager_1.TTSService.instance.on('stop', () => {
            this.addMessage({
                content: '',
                author: 'jibo'
            });
        });
        window.addEventListener('resize', () => {
            this.forceUpdate();
        });
    },
    incrementalMessageHandler(text) {
        let currMessages = this.refs.messagesList.state.messages;
        if (currMessages[currMessages.length - 1].author !== 'jibo') {
            this.refs.messagesList.addMessage({ author: 'jibo', content: "" });
        }
        this.refs.messagesList.appendMessage(text);
    },
    messageHandler(message) {
        this.addMessage({
            content: message.words,
            author: message.speaker
        });
        this.props.onWords(message);
    },
    addMessage(message) {
        if (message) {
            message.date = new Date();
            this.refs.messagesList.addMessage(message);
        }
    },
    render() {
        let paneClassName = 'chat-pane side-pane';
        if (!this.props.isSelected) {
            paneClassName += ' hidden';
        }
        return React.createElement("div", { className: paneClassName, ref: "root" },
            React.createElement(messages_list_1.default, { ref: "messagesList", reloadWatcher: this.props.reloadWatcher }),
            React.createElement(asr_view_1.default, { ref: "AsrView", ttsMode: this.props.ttsMode, speakerId: this.props.speakerId, loop: this.props.loop, messageHandler: this.messageHandler, onWords: this.props.onWords }));
    }
});

},{"./asr-view":5,"./messages-list":10,"react":undefined,"skills-service-manager":undefined}],9:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const target_view_1 = require("./target-view");
// import lpsService from '../services/lps-service';
const skills_service_manager_1 = require("skills-service-manager");
const animation_utilities_1 = require("animation-utilities");
const marked = require("marked");
const audio_event_1 = require("./audio-event");
let targetIndexCount = 0;
exports.default = React.createClass({
    getInitialState() {
        return {
            isSelected: false,
            targets: [],
            selectedTarget: ''
        };
    },
    initializeMouseTargetPositioner() {
        this.mtp = new animation_utilities_1.MouseTargetPositioner(this.props.visualizer, this.props.parent.getRobotRenderer().scene._camera, new animation_utilities_1.THREE.Vector3(0.2, 0, 0.2), //initial position of the target
        null, //point to define ground plane (0,0,0) is default if null)
        new animation_utilities_1.THREE.Vector3(0, 0, 1), //normal vector do define ground plane
        []);
        this.mtp.setMouseFilters(
        //Filter for MouseTargetPositioner.
        //filter determines which events to match/absorb
        //mouse events not matching this function will be fully ignored
        // (alt down but not meta or ctrl)
        function (event) { return event.altKey && !event.metaKey && !event.ctrlKey; }, 
        //filter to determine if a click is meant to move our ground plane location
        // (shift for ground plane clicking)
        function (event) { return event.shiftKey; }, 
        //filter to determine if a click is meant to move our camera plane location
        // (!shift for vertical (camera plane) clicking)
        function (event) { return !event.shiftKey; });
        this.mtp.addPositionChangedCallback(function (position, name) {
            if (name || name === 0) {
                let target = position;
                target.id = name;
                skills_service_manager_1.LPSService.instance.updateTarget(target);
            }
        });
        this.mtp.installRendererIntoScene(this.props.parent.getRobotRenderer().scene);
    },
    componentDidMount() {
        this.audioEvents = {};
        skills_service_manager_1.LPSService.instance.on('audio-event-start', (position, id) => {
            let scene = this.props.parent.getRobotRenderer().scene.getScene();
            let name = "sphere" + id;
            let audioEvent = new audio_event_1.default(scene, position, name);
            for (let key in this.audioEvents) {
                let audioEvent = this.audioEvents[key];
                audioEvent.setColor(0xffffff);
                audioEvent.setOpacity(0.5);
            }
            this.audioEvents[name] = audioEvent;
        });
        skills_service_manager_1.LPSService.instance.on('audio-event-end', (id) => {
            this.removeAudioEventById(id);
        });
    },
    removeAudioEventById(id) {
        let audioEvent = this.audioEvents["sphere" + id];
        audioEvent.startScaling(() => { });
    },
    addMouseTarget(targetId) {
        if (!this.mtp) {
            this.initializeMouseTargetPositioner();
        }
        this.mtp.addTargetPositioner(targetId);
        skills_service_manager_1.LPSService.instance.updateTarget({ id: targetId, x: 0.2, y: 0, z: 0.2 });
        this.setSelectedTarget(targetId);
        return true;
    },
    setSelectedTarget(targetId) {
        this.setState({
            selectedTarget: targetId
        });
        this.mtp.selectTarget(targetId);
    },
    showEntities() {
        console.log(this.mtp.getTargetPositionerNames());
        console.log(skills_service_manager_1.LPSService.instance.getEntities());
    },
    addTarget() {
        this.addMouseTarget(targetIndexCount++);
    },
    removeTarget(targetId) {
        skills_service_manager_1.LPSService.instance.removeEntity(targetId);
        this.mtp.removeTargetPositioner(targetId);
        this.forceUpdate();
    },
    render() {
        let paneClassName = 'lps-pane side-pane';
        if (!this.props.isSelected) {
            paneClassName += ' hidden';
        }
        let targets = [];
        let lpsTargets = skills_service_manager_1.LPSService.instance.getEntities();
        lpsTargets.forEach((target) => {
            let isSelected = target.id === this.state.selectedTarget;
            targets.push(React.createElement(target_view_1.default, { setTargetId: skills_service_manager_1.LPSService.instance.setTargetId.bind(skills_service_manager_1.LPSService.instance), target: target, isSelected: isSelected, removeTarget: this.removeTarget, onClick: this.setSelectedTarget }));
        });
        let markdown = "Click the `Add Target` button to add a single target to Jibo's Local Perceptual Space.\n\n" +
            "* `shift+scroll` to zoom in and out.\n\n" +
            "* `shift+drag` to move camera.\n\n" +
            "* `shift+alt+drag` to move the LPS target on the ground.\n\n" +
            "* `alt+drag` to move the height of the target.";
        let showEntities = null;
        showEntities = React.createElement("button", { className: "btn", onClick: this.showEntities },
            React.createElement("span", { className: "fa fa-terminal" }),
            " Show entities");
        return React.createElement("div", { className: paneClassName, ref: "rightPane" },
            React.createElement("div", { className: "panel-heading" },
                React.createElement("h2", { className: "target-heading" }, "Targets")),
            React.createElement("div", { className: "instructions", dangerouslySetInnerHTML: {
                    __html: marked(markdown, { sanitize: true })
                } }),
            React.createElement("div", { className: "lps-controls" },
                React.createElement("button", { className: "btn", onClick: this.addTarget },
                    React.createElement("span", { className: "fa fa-plus" }),
                    " Add Target"),
                showEntities),
            React.createElement("div", { className: 'arguments-scroll-container' }, targets));
    }
});

},{"./audio-event":6,"./target-view":12,"animation-utilities":undefined,"marked":undefined,"react":undefined,"skills-service-manager":undefined}],10:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const chat_message_1 = require("./chat-message");
exports.default = React.createClass({
    getInitialState() {
        return {
            messages: []
        };
    },
    componentDidMount() {
        this.props.reloadWatcher.on('reload', () => {
            this.addMessage({ break: true });
        });
    },
    /**
     * Message: {author: 'author', content: 'a sentence', date: Date()}
     */
    addMessage(message) {
        let messages = this.state.messages;
        messages.push(message);
        this.setState({
            messages: messages
        });
    },
    /**
     * Appends text to last message received,
     * or creates a new message if no messages have yet received.
     * Assumes new message comes from Jibo.
     */
    appendMessage(text) {
        if (text === '/pau/' || text === '<break>' || text === '<audioBreak>' || text === '<say-as>' || text === '[lpau]') {
            return;
        }
        let message = this.state.messages[this.state.messages.length - 1];
        if (!message) {
            message = {
                author: 'jibo',
                content: text,
                date: new Date()
            };
            this.addMessage(message);
        }
        else {
            message.content += text + ' ';
            this.forceUpdate();
        }
    },
    componentWillUpdate() {
        let container = this.refs.messageContainer.getDOMNode();
        this.shouldScrollBottom = container.scrollTop + container.offsetHeight + 15 >= container.scrollHeight;
    },
    componentDidUpdate() {
        if (this.shouldScrollBottom) {
            let container = this.refs.messageContainer.getDOMNode();
            container.scrollTop = container.scrollHeight;
        }
    },
    render() {
        let messages;
        messages = this.state.messages.map(function (m) {
            if (m.content === "") {
                return;
            }
            return (React.createElement(chat_message_1.default, { message: m }));
        });
        if (!messages.length) {
            messages = React.createElement("div", { className: "chat-no-messages" }, "No messages");
        }
        return (React.createElement("div", { ref: "messageContainer", className: "chat-messages" }, messages));
    }
});

},{"./chat-message":7,"react":undefined}],11:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
const skills_service_manager_1 = require("skills-service-manager");
const $ = require("jquery");
exports.default = React.createClass({
    getInitialState() {
        return {
            notifications: []
        };
    },
    componentWillMount() {
        skills_service_manager_1.NotificationsService.instance.on('notification-created', (notification) => {
            console.log(notification);
            this.state.notifications.push(notification);
            this.setState({
                notifications: this.state.notifications
            });
            let notifications = this.refs.notifications.getDOMNode(), styles = {
                message: {
                    backgroundColor: '#8B9B9C',
                    border: '4px solid #9FB1B3'
                },
                battery: {
                    backgroundColor: '#DE442F',
                    border: '4px solid #FF4E36'
                },
                alarm: {
                    backgroundColor: '#DE7400',
                    border: '4px solid #FF8500'
                },
                twitter: {
                    backgroundColor: '#338CDC',
                    border: '4px solid #3BA2FF'
                }
            };
            const $notifications = $(notifications);
            $notifications
                .append(`<div class="notification-item"><img class="${notification.type === "alarm" ? "shake-horizontal shake-constant" : ""}" src="assets/images/${notification.type}.png"/><h1>${notification.title}</h1><p>${notification.description}</p></div>`)
                .find(".notification-item:last")
                .css(styles[notification.type])
                .css({
                marginTop: "-89px"
            })
                .animate({
                marginTop: "1px"
            }, 250)
                .delay(1500)
                .animate({
                marginTop: "-89px"
            }, 250)
                .delay(2000).queue(function () {
                $(this).remove();
            });
        });
    },
    handleRemove() {
        // Do nothing for now, but could demo swiping to remove notfication popdowns faster
        // than their default auto disappearing time
    },
    render() {
        /*let notifications = this.state.notifications.map(function(notification, i) {
          return (
            <div className="notification-item" key={notification.id} onClick={this.handleRemove.bind(this, i)}>
              <h1>{notification.title}</h1>
              <p>{notification.description}</p>
            </div>
          );
      }.bind(this));*/
        return React.createElement("div", { className: "notifications", ref: "notifications" });
    }
});
/*<CSSTransitionGroup transitionName="notification-animation" transitionEnterTimeout={500} transitionLeaveTimeout={300}>
    {notifications}
</CSSTransitionGroup>*/

},{"jquery":undefined,"react":undefined,"skills-service-manager":undefined}],12:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.default = React.createClass({
    getInitialState() {
        return {
            id: this.props.target.id,
            isSelected: this.props.isSelected
        };
    },
    componentDidMount() {
        this.id = this.props.target.id;
    },
    onIdChange(event) {
        let value = event.target.value;
        this.props.setTargetId(this.props.target.id, value);
        this.setState({
            id: value
        });
    },
    onClick() {
        this.props.onClick(this.props.target.id);
    },
    onRemoveTarget() {
        this.setState({
            isSelected: true
        });
        this.props.removeTarget(this.props.target.id);
    },
    render() {
        let ray = this.props.target.parts[0].value.rays[0].dir;
        let k;
        for (k in ray) {
            ray[k] = Number(ray[k]).toFixed(5);
        }
        let className = this.props.isSelected ? "lpsTarget isSelected" : "lpsTarget unselected";
        return React.createElement("div", { className: className, onClick: this.onClick },
            React.createElement("button", { className: "btn remove", onClick: this.onRemoveTarget },
                React.createElement("span", { className: "fa fa-times" })),
            React.createElement("div", { className: "targetId" },
                React.createElement("span", { className: "title" }, "ID:"),
                React.createElement("span", { className: "value" }, this.props.target.id)),
            React.createElement("div", { className: "location" },
                React.createElement("span", { className: "value x" },
                    "x: ",
                    ray.x),
                ",",
                React.createElement("span", { className: "value y" },
                    "y: ",
                    ray.y),
                ",",
                React.createElement("span", { className: "value z" },
                    "z: ",
                    ray.z)));
    }
});

},{"react":undefined}],13:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const React = require("react");
exports.default = React.createClass({
    getInitialState() {
        return {};
    },
    componentWillMount() {
        this.showCameraView = false;
        document.addEventListener('click', (event) => {
            for (let target = event.target; target != document.body;) {
                if (target && target.id && target.id == 'viewTrigger') {
                    return;
                }
                if (!target.parentNode) {
                    break;
                }
                target = target.parentNode;
            }
            this.setShowCameraViewPopup(false);
        });
    },
    onCameraSelected(value) {
        this.props.setCamera(value.target.id);
        this.toggleCameraViewPicker();
    },
    toggleCameraViewPicker() {
        this.showCameraView = !this.showCameraView;
        this.forceUpdate();
    },
    selectMode(event) {
        this.mode = event.target.id;
        this.props.setMode(this.mode);
    },
    setShowCameraViewPopup(doShow) {
        this.showCameraView = doShow;
        this.forceUpdate();
    },
    render() {
        let showView = this.showCameraView ? "show" : "hide";
        let viewEnabled = this.showCameraView ? "selected" : "unselected";
        let audioMode = this.mode === "audio" ? "selected" : "unselected";
        let targetMode = this.mode === "target" ? "selected" : "unselected";
        return React.createElement("div", null,
            React.createElement("div", { className: "tools-top" },
                React.createElement("button", { id: "audio", className: "top main " + audioMode, onClick: this.selectMode },
                    React.createElement("span", { id: "audio", className: "fa fa-microphone icon" })),
                React.createElement("button", { id: "target", className: "top main " + targetMode, onClick: this.selectMode },
                    React.createElement("span", { id: "target", className: "fa fa-dot-circle-o icon" }))),
            React.createElement("div", { className: "tools-bottom" },
                React.createElement("button", { id: "viewTrigger", className: "bottom main " + viewEnabled, onClick: this.toggleCameraViewPicker },
                    React.createElement("span", { className: "fa fa-video-camera icon" })),
                React.createElement("div", { className: "popup  " + showView, id: "viewPopup" },
                    React.createElement("button", { className: "option", id: "viewTop", onClick: this.onCameraSelected }, "Top"),
                    React.createElement("button", { className: "option", id: "viewFront", onClick: this.onCameraSelected }, "Front"),
                    React.createElement("button", { className: "option", id: "viewReset", onClick: this.onCameraSelected }, "Reset"))));
    }
});

},{"react":undefined}],14:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * This is the entry point of the simulator app
 */
const React = require("react");
const skills_service_manager_1 = require("skills-service-manager");
const chat_view_1 = require("./views/chat-view");
const lps_view_1 = require("./views/lps-view");
const advanced_view_1 = require("./views/advanced-view");
const tab_bar_1 = require("./react-components/tab-bar");
const events_1 = require("events");
const skills_service_manager_2 = require("skills-service-manager");
const notifications_view_1 = require("./views/notifications-view");
const animation_utilities_1 = require("animation-utilities");
const jibo_kb_1 = require("jibo-kb");
const kb = new jibo_kb_1.KnowledgeBase();
const resolve = require('resolve');
//import findRoot = require('find-root');
//import path = require('path');
//require('./elements/custom-elements');
const face_on_body_1 = require("./face-on-body");
// import motorService from './services/motor-service';
const dimensions_1 = require("./dimensions");
const async = require("async");
const path = require("path");
const electron_1 = require("electron");
// This is to prevent a bug where jibo-tools and skills-service-manager end up sharing the same animation-utilities,
// this causes issues as jibo's wrapVisualize changes the signature of visualize.createRobotRenderer by dropping the
// the robotInfo parameter.
// See: https://github.jibo.com/sdk/jibo/blob/079e5a50fafc27b26556687b2b8f339ea214560c/src/utils/AnimationUtils.js#L77-L98
const createRobotRenderer = animation_utilities_1.visualize.createRobotRenderer;
let previousSettings, settings;
// TODO:
/*
    - persist names/chat history
    - replay convos
    - wav as audio files
    - make scrolling work
    - auto keyboard focus
*/
let isRemoteMode = electron_1.ipcRenderer.sendSync('is-remote-mode') === "true";
if (isRemoteMode) {
    dimensions_1.default.CHAT_WIDTH = 0;
}
// The last GL instance we subscribed to for HJ events which we use to
// simulate the localized HJ entities in the LPS stream.
// This is needed to successfully re-subscribe to new GL instance after skill reload
let lastGLInstance;
/*let View = */
let View = React.createClass({
    getInitialState() {
        return {
            currentView: 'chat'
        };
    },
    componentWillMount() {
        this.reloadWatcher = new events_1.EventEmitter();
        previousSettings = settings = JSON.parse(electron_1.ipcRenderer.sendSync('get-simulator-settings'));
    },
    render() {
        let tabs = [
            {
                label: 'Chat',
                id: 'chatTab',
                icon: "icon fa fa-comment",
                callback: (() => {
                    this.setState({
                        currentView: 'chat'
                    });
                })
            },
            {
                label: 'LPS',
                id: 'lpsTab',
                icon: "icon fa fa-compass",
                callback: (() => {
                    this.setState({
                        currentView: 'lps'
                    });
                })
            },
            {
                label: 'Advanced',
                id: 'advancedTab',
                icon: "icon fa fa-cog",
                callback: (() => {
                    this.setState({
                        currentView: 'advanced'
                    });
                })
            }
        ];
        let isChat = (this.state.currentView === 'chat');
        let isLps = (this.state.currentView === 'lps');
        let isAdvanced = (this.state.currentView === 'advanced');
        if (!isRemoteMode) {
            let tabView, chatView, lpsView, advancedView;
            tabView = React.createElement(tab_bar_1.default, { tabs: tabs });
            chatView = React.createElement(chat_view_1.default, { ref: "chat", loop: this.props.loop, speakerId: settings.speakerId, ttsMode: settings.ttsMode, onWords: this.onWords, isSelected: isChat, reloadWatcher: this.reloadWatcher });
            lpsView = React.createElement(lps_view_1.default, { ref: "lps", isSelected: isLps, robotRenderer: this.robotRenderer, parent: this, visualizer: this.visualizer, updateTargets: this.forceUpdate.bind(this) });
            advancedView = React.createElement(advanced_view_1.default, { ref: "advanced", isSelected: isAdvanced });
            return React.createElement("div", null,
                tabView,
                chatView,
                lpsView,
                advancedView);
        }
        else {
            return React.createElement("div", null);
        }
    },
    getVisualizerContainer() {
        return this.visualizer;
    },
    getRobotRenderer() {
        return this.robotRenderer;
    },
    componentDidMount() {
        if (skills_service_manager_1.LPSService.instance) {
            skills_service_manager_1.LPSService.instance.on('update', () => {
                this.forceUpdate();
            });
        }
        // Listen for changes to the devTools visibility state
        let counter = 0;
        let onSettingsChanged = (_previousSettings, newSettings) => {
            previousSettings = _previousSettings;
            settings = newSettings;
            // Force a redraw so any component that uses the settings can redraw
            if (previousSettings.ttsMode !== settings.ttsMode) {
                if (counter < 20) {
                    counter++;
                    this.forceUpdate();
                }
            }
        };
        // Get the jibo container
        const container = document.getElementById('container');
        const face = document.getElementById('face');
        const visualizer = document.getElementById('visualizer');
        const skillWebview = document.getElementById('skill');
        this.visualizer = visualizer;
        face_on_body_1.default.init(this.props.robotInfo, createRobotRenderer, container, face, visualizer, onSettingsChanged, (err, robotRenderer, _settings) => {
            settings = _settings;
            // Display the loader screen on top of the webview until it's ready
            // loader.style.visibility = "visible";
            face.className = "loading";
            electron_1.ipcRenderer.on('reload-skill', () => {
                skillWebview.reloadIgnoringCache();
            });
            skillWebview.addEventListener('did-start-loading', () => {
                face.className = "loading";
                this.reloadWatcher.emit('reload');
                // HACK: This is work around for an issue that we can't explain where initially the webview content
                // is all white until you do something that creates a resize of sorts
                webviewWhiteScreenWorkaround(skillWebview);
            });
            // Get the skill's path and then load it into the webview that it will run in it
            this.robotRenderer = robotRenderer;
            // Listen for the main process gets a user command (keypress or menu) to toggle the dev tool of the skill
            let ignoreNextDevToolsClosedEvent = false;
            electron_1.ipcRenderer.on('toggle-dev-tools', (sender, showDevTools) => {
                if (showDevTools) {
                    skillWebview.openDevTools();
                }
                else {
                    ignoreNextDevToolsClosedEvent = true;
                    skillWebview.closeDevTools();
                }
            });
            skillWebview.addEventListener('devtools-closed', () => {
                if (ignoreNextDevToolsClosedEvent) {
                    ignoreNextDevToolsClosedEvent = false;
                    return;
                }
                //console.warn('devtools-closed');
                electron_1.ipcRenderer.send('close-dev-tools');
            });
            const onDomReady = () => {
                // Restore state of devtools visibility
                if (!skillWebview.isDevToolsOpened() && settings.isDevToolsOpened) {
                    skillWebview.openDevTools();
                }
                else if (skillWebview.isDevToolsOpened() && !settings.isDevToolsOpened) {
                    skillWebview.closeDevTools();
                }
                // Inject a few default body properties
                skillWebview.insertCSS('html{min-width: 1280px; min-height: 720px;} body{min-width: 1280px; min-height: 720px; margin: 0px; overflow: hidden;}');
                skillWebview.addEventListener('devtools-closed', () => {
                    if (ignoreNextDevToolsClosedEvent) {
                        ignoreNextDevToolsClosedEvent = false;
                        return;
                    }
                    //console.warn('devtools-closed');
                    electron_1.ipcRenderer.send('close-dev-tools');
                });
                // Hide loader screen now
                face.className = "";
                // Fake HJ audio entity based on SSM-GL HJ event
                if (!lastGLInstance || lastGLInstance !== skills_service_manager_1.GlobalListen.getInstance()) {
                    lastGLInstance = skills_service_manager_1.GlobalListen.getInstance();
                    skills_service_manager_1.GlobalListen.getInstance().events.listen.hjHeard.on(() => {
                        skills_service_manager_1.LPSService.instance.triggerSimulatedHJEvent();
                    });
                }
            };
            // Listen for when the skill's page's dom is ready, then show the webview
            skillWebview.addEventListener("dom-ready", onDomReady);
            if (skills_service_manager_1.BodyService.instance) {
                // Start loop that updates the visualizer
                skills_service_manager_1.BodyService.instance.on('update', (dofs) => {
                    robotRenderer.display(dofs);
                });
            }
            skillWebview.src = electron_1.ipcRenderer.sendSync('get-skill-path');
        });
    },
    onWords(wordOptions) {
        skills_service_manager_1.ASRService.instance.onWordsReceived(wordOptions);
    }
});
async.series([
    (next) => {
        if (!isRemoteMode) {
            // get the root directory for the SSM. this changed due to the lerna mono repo restructing
            let rootDir = path.join(resolve.sync('skills-service-manager', { basedir: __dirname }), '..');
            let factory = new skills_service_manager_2.Factory({
                RegistryService: {
                    host: '127.0.0.1',
                    port: 0
                },
                services: {
                    KBService: {
                        port: 0
                    },
                    TTSService: {
                        port: 0
                    },
                    LPSService: {
                        port: 0
                    },
                    ASRService: {
                        port: 0
                    },
                    ListenService: {
                        port: 0
                    },
                    GlobalManagerService: {
                        port: 0
                    },
                    BodyService: {
                        port: 0
                    },
                    ErrorService: {
                        port: 0
                    },
                    SystemMonitoringServiceSim: {
                        port: 0
                    },
                    NLUService: {
                        port: 0
                    },
                    NotificationsService: {
                        port: 0
                    },
                    MediaService: {
                        port: 0
                    },
                    MediaManagerService: {
                        port: 0
                    },
                    ServerService: {
                        port: 0
                    },
                    SystemManagerService: {
                        port: 0
                    },
                    SchedulerService: {
                        port: 0
                    },
                    ExpressionService: {
                        port: 0
                    },
                    SkillsServiceSim: {
                        port: 0,
                        skillsBaseDir: path.join(electron_1.ipcRenderer.sendSync('get-skill-path'), '..')
                    },
                    SecureTransferServiceSim: {
                        port: 0
                    },
                    AudioServiceSim: {
                        port: 0
                    },
                    WifiService: {
                        port: 0
                    },
                }
            }, rootDir);
            factory.init(() => {
                const registryServiceURL = `http://127.0.0.1:${skills_service_manager_2.RegistryClient.instance.port}/registry`;
                electron_1.ipcRenderer.send('registry-init', registryServiceURL);
                //console.log("Registry Service URL: " + registryServiceURL);
                next();
            });
        }
        else {
            electron_1.ipcRenderer.send('registry-init', 'http://127.0.0.1:8181');
            next();
        }
    },
    (next) => {
        kb.init({
            host: '127.0.0.1',
            port: skills_service_manager_2.KBService.instance.port
        }, () => {
            kb.initLoop();
            kb.initMedia();
            next();
        });
    },
    (next) => {
        kb.loop.loadLoop((err, members) => {
            if (err) {
                members = [];
            }
            let config = new animation_utilities_1.JiboConfig();
            animation_utilities_1.RobotInfo.createInfo(config, (robotInfo) => {
                React.render(React.createElement(View, { robotInfo: robotInfo, asrService: skills_service_manager_1.ASRService.instance, loop: members }), document.getElementById('sidebar'));
                React.render(React.createElement(notifications_view_1.default, null), document.getElementById('notifications'));
                next();
            });
        });
    }
], function (err) {
    if (err) {
        console.error(`Simulator: ${err}`);
    }
});
/*
 * This all basically simulates the manuel workaround we had before to get rid of the white screen
 * issue on first loading the simulator. We will be talking to Electron/Github to get a proper
 * solution going.
 */
function webviewWhiteScreenWorkaround(webview) {
    webview.style.width = "0px";
    webview.style.height = "0px";
    webview.addEventListener("did-finish-load", function () {
        webview.style.width = "1280px";
        webview.style.height = "720px";
    });
}

},{"./dimensions":1,"./face-on-body":2,"./react-components/tab-bar":3,"./views/advanced-view":4,"./views/chat-view":8,"./views/lps-view":9,"./views/notifications-view":11,"animation-utilities":undefined,"async":undefined,"electron":undefined,"events":undefined,"jibo-kb":undefined,"path":undefined,"react":undefined,"resolve":undefined,"skills-service-manager":undefined}]},{},[14])(14)
});

//# sourceMappingURL=client.js.map
