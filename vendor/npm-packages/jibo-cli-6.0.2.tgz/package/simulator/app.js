(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.app = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * This file is responsible for saving/restoring the devTools state such as shown/hidden
 * and it s window's position/size
 */
const settings_1 = require("./settings");
// import BrowserWindow = require('browser-window');
exports.default = {
    init(mainWindow) {
        this.mainWindow = mainWindow;
        // let screen = require('screen');
        // Open the devtools if they were open when the last session ran
        if (settings_1.default.get('isSimulatorDevToolsOpened')) {
            this.mainWindow.webContents.openDevTools();
        }
        // Track changes to the visibility of the devTools so we can restore that
        // state on reopening the devTools
        this.mainWindow.webContents.on('devtools-opened', () => {
            settings_1.default.update({
                isSimulatorDevToolsOpened: true
            });
            // Reinstate the devTools window properties
            if (this.mainWindow.webContents.devToolsWebContents) {
                let devToolsWindow = mainWindow.webContents.devToolsWebContents.getOwnerBrowserWindow();
                devToolsWindow.setPosition(settings_1.default.get('devToolsWindowX'), settings_1.default.get('devToolsWindowY'));
            }
        });
        this.mainWindow.webContents.on('devtools-closed', () => {
            settings_1.default.update({
                isSimulatorDevToolsOpened: false
            });
        });
    },
    shutdown() {
        if (this.devToolsWindowDimensionChangesInterval) {
            clearInterval(this.devToolsWindowDimensionChangesInterval);
            this.devToolsWindowDimensionChangesInterval = null;
        }
    }
};

},{"./settings":2}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const fs = require("fs-extra");
const _ = require("lodash/lodash.min");
const electron_1 = require("electron");
function getUserHome() {
    return process.env[(process.platform == 'win32') ? 'USERPROFILE' : 'HOME'];
}
let settingsPath = path.join(getUserHome(), "./jibo/simulator/settings.json"), defaults = {
    // We remember what the content dimensions not window dimensions were
    // in case the chrome of the simulator changes over time. We use this to
    // set the window size such that the content dimensions match these settings
    contentWidth: 1280,
    contentHeight: 720,
    // TODO: Make it smartly center instead on first loading up
    windowX: 50,
    windowY: 50,
    fullscreen: false,
    // Defaults to pixel perfect
    zoomFactorIndex: 4,
    zoomFactor: 1,
    viewMode: '3d',
    devToolsWindowX: 0,
    devToolsWindowY: 0,
    devToolsContentWidth: 1200,
    devToolsContentHeight: 800,
    isSimulatorDevToolsOpened: false,
    isDevToolsOpened: false,
    isBackgroundServiceDevToolsOpened: false,
    ttsMode: "Instant"
};
exports.default = {
    init() {
        try {
            if (fs.existsSync(settingsPath) === true) {
                this._settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
                this._settings = _.extend({}, defaults, this._settings);
            }
            else {
                this._settings = defaults;
            }
        }
        catch (e) {
            //console.error('Error loading simulator settings file. Error: '+e);
            this._settings = defaults;
        }
        // We don't start sending change notifications of the settings
        // until the simulator is ready. We consider it ready when it first asks
        // for the simulator settings
        this.simulatorReady = false;
        electron_1.ipcMain.on('get-simulator-settings', (event) => {
            let windowing = require('./windowing').default;
            event.returnValue = JSON.stringify(this._settings);
            this.simulatorReady = true;
            this.update({
                zoomFactor: windowing.getZoom()
            });
        });
        // Listen for events from the simulator's render process for when users used the mouse to
        // close devTools
        electron_1.ipcMain.on('close-dev-tools', () => {
            this.update({
                isDevToolsOpened: false
            });
        });
        electron_1.ipcMain.on('close-background-service-dev-tools', () => {
            this.update({
                isBackgroundServiceDevToolsOpened: false
            });
        });
        electron_1.ipcMain.on('set-tts-mode', (event, mode) => {
            console.log('set-tts-mode ', mode);
            this.update({
                ttsMode: mode
            });
        });
        electron_1.ipcMain.on('set-speaker-id', (event, id) => {
            console.log('set-speaker-id ', id);
            this.update({
                speakerId: id
            });
        });
    },
    setWindow(mainWindow) {
        this.mainWindow = mainWindow;
    },
    toggleSkillDevTools() {
        // Make sure this change is serialized
        this.update({
            isDevToolsOpened: !this.get('isDevToolsOpened')
        });
        // Send event telling the simulator process to toggle the devtools of the skill
        if (this.simulatorReady === true) {
            this.mainWindow.webContents.send('toggle-dev-tools', this._settings.isDevToolsOpened);
        }
    },
    update(changes) {
        this._settings = _.extend({}, this._settings, changes);
        //console.log('saved');
        //console.log(this._settings);
        fs.ensureDirSync(path.dirname(settingsPath));
        fs.writeFileSync(settingsPath, JSON.stringify(this._settings, null, '    '), 'utf8');
        // Notify runtime about the change
        if (this.simulatorReady === true) {
            this.mainWindow.webContents.send('simulator-settings-changed', JSON.stringify(this._settings));
        }
    },
    get(name) {
        return this._settings[name];
    },
    all() {
        return this._settings;
    }
};

},{"./windowing":3,"electron":undefined,"fs-extra":undefined,"lodash/lodash.min":undefined,"path":undefined}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const settings_1 = require("./settings");
const electron_1 = require("electron");
const electron = require('electron');
let // Different zoom levels the simulator can be in. These are based on the zoom
// levels that chrome uses for each increment.
zoomFactors = [
    // We actually removed 0.25 and 0.33 as it was uselessly small and it
    // was confusing when showing dev tools as they wouldn't be visible even though
    // they were 'showing'
    0.50,
    0.67,
    0.75,
    0.90,
    1.0,
    1.1,
    1.25,
    1.5,
    1.75,
    2.0,
    2.5,
    3.0,
    4.0,
    5.0 // 500% (13)
], 
// Special zoom factors
// (100%)
PIXELPERFECT = 4, 
// (200%)
// DOUBLESIZED = 9,
// Lifesized's zoom factor is dependent on which display it's on, so we
// reserve -2 as the value indicating we're at the lifesized zoom level
LIFESIZED = -2, currentZoomFactor = 1, zoomMultiplier = 1, mainWindow = null;
let windowing = {
    init() {
        currentZoomFactor = settings_1.default.get('zoomFactorIndex');
        zoomMultiplier = (currentZoomFactor === LIFESIZED) ? 1.0 : zoomFactors[currentZoomFactor];
    },
    /**
     * Set the main window to be zoomed
     */
    setWindow(_mainWindow) {
        mainWindow = _mainWindow;
        // Add keyboard shortcut for setting the zoom level back 100%
        // Command+0 is what people are used to at least in Chrome/Firefox
        electron_1.globalShortcut.register('CmdOrCtrl+0', function () {
            windowing.reset();
        });
        // Listen for and save changes to the window size and position
        /*let previousDimensions = {
            x: settings.get('windowX'),
            y: settings.get('windowY'),
            width: settings.get('contentWidth'),
            height: settings.get('contentHeight'),
            devicePixelRatio: this.getScaleFactor()
        };*/
        this.dimensionChangeInterval = setInterval(() => {
            let contentSize = mainWindow.getContentSize(), scaleFactor = this.getScaleFactor();
            if (settings_1.default.get('windowX') !== mainWindow.getBounds().x ||
                settings_1.default.get('windowY') !== mainWindow.getBounds().y ||
                settings_1.default.get('contentWidth') !== (contentSize[0] * scaleFactor) ||
                settings_1.default.get('contentHeight') !== (contentSize[1] * scaleFactor) ||
                settings_1.default.get('devicePixelRatio') !== scaleFactor) {
                settings_1.default.update({
                    windowX: mainWindow.getBounds().x,
                    windowY: mainWindow.getBounds().y,
                    // Take into consideration the scale factor so that the window's
                    // size actually ends up being the correct pixel density, not
                    // higher res because of retina screen scaleFactors
                    contentWidth: contentSize[0] * scaleFactor,
                    contentHeight: contentSize[1] * scaleFactor,
                    // We provide the devicePixelRatio to the runtime as electron
                    // always reports things in real pixels and ignores the whole virtual
                    // pixel retina design debacle
                    devicePixelRatio: scaleFactor
                });
            }
        }, 200);
    },
    shutdown() {
        if (this.dimensionChangeInterval) {
            clearInterval(this.dimensionChangeInterval);
        }
    },
    getZoom() {
        return zoomMultiplier;
    },
    getInitialZoomFactor() {
        return this.getZoom();
    },
    // Get the best guess of which display the window is over
    getDisplay() {
        // If we have a window, use it's bounds
        if (mainWindow) {
            return electron.screen.getDisplayMatching(mainWindow.getBounds());
        }
        else {
            return electron.screen.getDisplayMatching({
                x: settings_1.default.get('windowX'),
                y: settings_1.default.get('windowY'),
                width: settings_1.default.get('contentWidth'),
                height: settings_1.default.get('contentHeight')
            });
        }
    },
    getScaleFactor() {
        let display = this.getDisplay();
        return display.scaleFactor;
    },
    getMenuItems() {
        return [
            {
                label: 'Toggle Full Screen',
                accelerator: 'Ctrl+Command+F',
                click: function () {
                    if (mainWindow) {
                        mainWindow.setFullScreen(!mainWindow.isFullScreen());
                        settings_1.default.update({
                            fullscreen: mainWindow.isFullScreen()
                        });
                    }
                }
            },
            {
                label: 'Actual Sized (100%)',
                accelerator: 'CmdOrCtrl+0',
                click: function () {
                    setMainWindowZoom(PIXELPERFECT);
                }
            },
            {
                label: 'Zoom In',
                accelerator: 'CmdOrCtrl+=',
                click: function () {
                    if (currentZoomFactor === LIFESIZED) {
                        setMainWindowZoom(PIXELPERFECT);
                    }
                    else {
                        setMainWindowZoom(currentZoomFactor + 1);
                    }
                }
            },
            {
                label: 'Zoom Out',
                accelerator: 'CmdOrCtrl+-',
                click: function () {
                    if (currentZoomFactor === LIFESIZED) {
                        setMainWindowZoom(PIXELPERFECT);
                    }
                    else {
                        setMainWindowZoom(currentZoomFactor - 1);
                    }
                }
            },
            {
                label: 'Physical Sized',
                accelerator: 'CmdOrCtrl+4',
                click: function () {
                    setMainWindowZoom(LIFESIZED);
                }
            },
            {
                type: 'separator'
            },
            {
                label: '2D View',
                accelerator: 'CmdOrCtrl+2',
                click: function () {
                    settings_1.default.update({
                        viewMode: '2d'
                    });
                }
            },
            {
                label: '3D View',
                accelerator: 'CmdOrCtrl+3',
                click: function () {
                    settings_1.default.update({
                        viewMode: '3d'
                    });
                }
            },
            {
                type: 'separator'
            }
        ];
    },
    /**
     * Set the zoom level to a pixel perfect 100%
     */
    reset() {
        setMainWindowZoom(PIXELPERFECT);
    }
};
/**
 * Set the zoom level of the main window and optionally its dimensions to
 * to perfectly crop the content at the specified zoom level
 */
function setMainWindowZoom(zoomFactor) {
    let display;
    // Make sure the zoomFactor isn't outside the bounds of zoomFactors value range
    if ((zoomFactor < 0 && zoomFactor !== LIFESIZED) || zoomFactor >= zoomFactors.length) {
        return;
    }
    currentZoomFactor = zoomFactor;
    // console.log(currentZoomFactor);
    // console.log(zoomFactors[currentZoomFactor]);
    // Figure out the actual zoom multiplier
    // If it's set to REALSIZED then calculate it
    if (zoomFactor === LIFESIZED) {
        // Guess at which display the main window is over
        display = electron.screen.getDisplayMatching(mainWindow.getBounds());
        let lifesized = require('lifesized'), ppi = lifesized.ppi(display), 
        // According to this spec document I found:
        // https://confluence.jibo.com/download/attachments/2556665/PS-TM8002-01%20REV10.pdf?version=1&modificationDate=1429538990000&api=v2
        // ...Jibo's screen is: 4.9" diagonally
        // Using the good old pythagorean theorem we can figure out
        // the width and height jibo's window should be (ok I cheated and used: http://dpi.lv/)
        jiboScreenDPI = 300;
        zoomMultiplier = ppi / jiboScreenDPI * display.scaleFactor;
    }
    else {
        zoomMultiplier = zoomFactors[currentZoomFactor];
    }
    display = electron.screen.getDisplayMatching(mainWindow.getBounds());
    settings_1.default.update({
        'zoomFactor': zoomMultiplier / display.scaleFactor,
        'zoomFactorIndex': currentZoomFactor
    });
}
exports.default = windowing;

},{"./settings":2,"electron":undefined,"lifesized":undefined}],4:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path = require("path");
const program = require("commander");
const settings_1 = require("./settings");
const dev_tools_1 = require("./dev-tools");
const windowing_1 = require("./windowing");
const findRoot = require("find-root");
let mainWindow = null;
// Add text to speech enabling flag
electron_1.app.commandLine.appendSwitch('enable-speech-dispatcher');
// Figure out which short cut style we should do based on the current platform
let toggleDevToolsShortcutStem = 'Alt+Command+';
if (process.platform != 'darwin') {
    toggleDevToolsShortcutStem = 'Shift+Control+';
}
program
    .option('-p, --path <path>', 'The path to the skill')
    .option('-r, --remote <address>', 'Run this as a remote simulation')
    .option('-t, --token <token>', 'Run this as a remote simulation')
    .option('-f, --frameless', 'Run with frameless window (no menu bar)')
    .parse(process.argv);
let inRemoteMode = typeof program.remote !== 'undefined' && program.remote.length > 0;
/*
 * Only allow one instance of the simulator to exist
 */
let shouldQuit = electron_1.app.makeSingleInstance(() => {
    return true;
});
if (shouldQuit) {
    electron_1.app.on('ready', () => {
        let template = [
            {
                label: 'Electron',
                submenu: [
                    {
                        label: 'Quit',
                        accelerator: 'CommandOrControl+Q',
                        click: () => {
                            electron_1.app.quit();
                        }
                    }
                ]
            }
        ];
        const menu = electron_1.Menu.buildFromTemplate(template);
        electron_1.Menu.setApplicationMenu(menu);
        let dialogWindow = new electron_1.BrowserWindow({
            useContentSize: true,
            width: 400,
            height: 200,
            resizable: false
        });
        // Load the visualizer web app which will itself load the skill's index.html
        dialogWindow.loadURL('file://' + path.join(findRoot(__dirname), 'single-instance-dialog.html'));
        //dialogWindow.webContents.toggleDevTools();
        dialogWindow.on('closed', () => {
            dialogWindow = undefined;
        });
    });
    //throw new Error('Only one instance of Jibo\'s Simulator can run at once.');
}
else {
    electron_1.ipcMain.on('is-remote-mode', (event) => {
        event.returnValue = inRemoteMode.toString();
    });
    if (!program.path) {
        console.error('You must specify a --path');
        process.exit(1);
    }
    settings_1.default.init();
    /**
     * This is called by the visualizer when running in the simulator. It uses
     * this to load in the entire simulator module. This way the simulator module doesn't
     * bloat up the size of the jibo module.
     */
    electron_1.ipcMain.on('get-skill-path', (event) => {
        event.returnValue = program.path;
    });
    /**
     * Called by the simulator to get the path to the background service's main entry point.
     * Returns an empty string if the skill doesn't have a background service
     */
    electron_1.ipcMain.on('get-background-service-path', (event) => {
        // Search for the closest folder in the same folder or above of the skill's
        // path that includes a package.json
        let skillRoot = findRoot(program.path);
        // Open it's package.json and look for a jibo.backgroundMain entry
        let packageJson = require(path.resolve(skillRoot, 'package.json'));
        if (typeof packageJson.jibo !== 'undefined' &&
            typeof packageJson.jibo === 'object' &&
            typeof packageJson.jibo.backgroundMain === 'string') {
            event.returnValue = path.resolve(skillRoot, packageJson.jibo.backgroundMain);
        }
        else {
            event.returnValue = "";
        }
    });
    let template = [
        {
            label: 'Electron',
            submenu: [
                {
                    label: 'Quit',
                    accelerator: 'CommandOrControl+Q',
                    click: () => {
                        electron_1.app.quit();
                    }
                }
            ]
        },
        {
            label: 'Edit',
            submenu: [
                { label: 'Undo', accelerator: 'Command+Z', selector: 'undo:' },
                { label: 'Redo', accelerator: 'Command+Shift+Z', selector: 'redo:' },
                { type: 'separator' },
                { label: 'Cut', accelerator: 'Command+X', selector: 'cut:' },
                { label: 'Copy', accelerator: 'Command+C', selector: 'copy:' },
                { label: 'Paste', accelerator: 'Command+V', selector: 'paste:' },
                { label: 'Select All', accelerator: 'Command+A', selector: 'selectAll:' }
            ]
        },
        {
            label: 'View',
            submenu: [
                {
                    label: 'Reload',
                    accelerator: 'CommandOrControl+R',
                    click: () => {
                        if (mainWindow) {
                            mainWindow.webContents.send('reload-skill');
                        }
                    }
                },
                {
                    type: 'separator'
                }
            ]
                .concat(windowing_1.default.getMenuItems())
                .concat(addDebugging())
        }
    ];
    // Quit the program if all windows are closed
    electron_1.app.on('window-all-closed', () => {
        electron_1.app.quit();
    });
    electron_1.app.on('ready', () => {
        // Set the context menu
        let menu = electron_1.Menu.buildFromTemplate(template);
        electron_1.Menu.setApplicationMenu(menu);
        loadSkill();
    });
}
function addDebugging() {
    return [
        {
            label: 'Developer',
            submenu: [
                {
                    label: 'Developer Tools',
                    accelerator: toggleDevToolsShortcutStem + 'I',
                    click: () => {
                        if (mainWindow) {
                            settings_1.default.toggleSkillDevTools();
                        }
                    }
                },
                {
                    label: 'Developer Tools (Skills Service Manager)',
                    accelerator: toggleDevToolsShortcutStem + 'J',
                    click: () => {
                        if (mainWindow) {
                            mainWindow.webContents.toggleDevTools();
                        }
                    }
                }
            ]
        }
    ];
}
function loadSkill() {
    let registryHost = inRemoteMode ? program.remote : undefined;
    //
    if (!inRemoteMode) {
        // The simulator window tell us where the registry end point is
        electron_1.ipcMain.on('registry-init', (event, _registryHost) => {
            console.log(registryHost);
            registryHost = _registryHost;
        });
    }
    // Set the window size taking into consideration retina display type
    // monitors so that our simulation window is pixel perfect
    let screen = require('electron').screen, display;
    // Try to guess which screen the window will end up so that we can
    // factor in the display's scaleFactor
    try {
        display = screen.getDisplayMatching({
            x: settings_1.default.get('windowX'),
            y: settings_1.default.get('windowY'),
            width: settings_1.default.get('contentWidth'),
            height: settings_1.default.get('contentHeight')
        });
    }
    catch (error) {
        display = screen.getDisplayMatching({
            x: 100,
            y: 100,
            width: 1000,
            height: 1000 // settings.get('contentHeight')
        });
    }
    // Force 2d mode if running remote mode
    if (inRemoteMode) {
        settings_1.default.update({
            viewMode: '2d'
        });
    }
    const options = {
        //'zoom-factor': windowing.getInitialZoomFactor()
        partition: "persist:jibo-simulator"
    };
    if (settings_1.default.get('fullscreen')) {
        options.fullscreen = true;
    }
    else {
        // This ensures the width/height of the body are actually what we set
        // and unaffected by os specific window framing elements
        options.useContentSize = true;
        options.x = settings_1.default.get('windowX');
        options.y = settings_1.default.get('windowY');
        options.width = settings_1.default.get('contentWidth') / display.scaleFactor;
        options.height = settings_1.default.get('contentHeight') / display.scaleFactor;
    }
    mainWindow = new electron_1.BrowserWindow(options);
    dev_tools_1.default.init(mainWindow);
    windowing_1.default.setWindow(mainWindow);
    settings_1.default.setWindow(mainWindow);
    electron_1.ipcMain.on('get-context', (event) => {
        event.sender.send('set-context', {
            registryHost: registryHost,
            token: program.token
        });
    });
    let indexPath = program.path;
    // Make sure the working directory is the root directory of the skill
    process.chdir(path.dirname(indexPath));
    // Load the visualizer web app which will itself load the skill's index.html
    mainWindow.loadURL('file://' + path.join(findRoot(__dirname), 'index.html'));
    mainWindow.on('closed', () => {
        shutdown(mainWindow);
    });
}
function shutdown(windowThatClosed) {
    if (mainWindow) {
        if (mainWindow !== windowThatClosed) {
            mainWindow.close();
        }
        mainWindow = null;
    }
    windowing_1.default.shutdown();
    dev_tools_1.default.shutdown();
}

},{"./dev-tools":1,"./settings":2,"./windowing":3,"commander":undefined,"electron":undefined,"find-root":undefined,"path":undefined}]},{},[4])(4)
});

//# sourceMappingURL=app.js.map
