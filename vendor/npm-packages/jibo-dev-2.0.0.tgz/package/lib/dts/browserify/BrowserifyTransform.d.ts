/**
 * @description Transform for Browserify to compile `.bt` and `.flow` files into source.
 * ```
 * var browserify = require('browserify');
 * browserify().transform('jibo-dev/browserify-transform');
 * ```
 * ```
 * {
 *     "browserify": {
 *         "transform": [
 *             "jibo-dev/browserify-transform"
 *         ]
 *     }
 * }
 * ```
 * @class BrowserifyTransform
 * @param filename {string} `.bt` or `.flow` file to compile.
 */
export default function BrowserifyTransform(filename: any): NodeJS.ReadWriteStream;
