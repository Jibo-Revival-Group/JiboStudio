import Behaviorify from './Behaviorify';
/**
 * API to convert `.flow` files into JavaScript.
 * ```
 * import {Flowify} = require('jibo-dev');
 * const flow = new Flowify('/path/to/custom.flow');
 * console.log(flow.exec());
 * ```
 * @class Flowify
 * @param {String} filename Path and name of the file to compile.
 * @param {Object} [data] The parsed JSON file to load.
 */
export default class Flowify extends Behaviorify {
    /**
     * Browserify transform.
     * @method Flowify.transform
     * @private
     * @param {String} filename File name.
     * @param {String} source Buffer from source file.
     * @return {String} Output JavaScript module buffer.
     */
    static transform(filename: string, source: string): string;
    constructor(filename: string, data?: {
        [id: string]: any;
    });
}
