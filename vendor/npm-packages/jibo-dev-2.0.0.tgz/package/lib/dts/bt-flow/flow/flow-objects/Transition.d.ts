declare class Transition {
    frm: string;
    to: string;
    value: string;
    constructor(frm: string, to: string, value: string);
}
export default Transition;
