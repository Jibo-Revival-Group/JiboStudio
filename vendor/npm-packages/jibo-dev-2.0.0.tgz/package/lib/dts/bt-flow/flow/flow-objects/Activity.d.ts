import Procedure from './Procedure';
import Transition from './Transition';
declare class Activity {
    class: string;
    assetPack: string;
    id: string;
    name: string;
    procedure: Procedure;
    transitions: Transition[];
    exceptions: Transition[];
    options: any;
    constructor(name: string, id: string, className: string, assetPack: string, options: any);
    set_transitions(transitions: Transition[]): void;
    set_exceptions(exceptions: Transition[]): void;
}
export default Activity;
