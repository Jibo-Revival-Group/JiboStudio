import Activity from './Activity';
import Transition from './Transition';
declare class Procedure {
    name: string;
    uri: string;
    activities: {
        [key: string]: Activity;
    };
    local_inits: {
        [key: string]: string;
    };
    param_inits: {
        [key: string]: string;
    };
    transitions: {
        [key: string]: Transition[];
    };
    exceptions: {
        [key: string]: Transition[];
    };
    procedureConstructor: any;
    constructor(name: string, uri: string, local_inits: {
        [key: string]: string;
    }, param_inits: {
        [key: string]: string;
    });
    add_transition(transition: Transition): void;
    add_activity(activity: Activity): void;
    toBehaviorifyable(): any;
}
export default Procedure;
