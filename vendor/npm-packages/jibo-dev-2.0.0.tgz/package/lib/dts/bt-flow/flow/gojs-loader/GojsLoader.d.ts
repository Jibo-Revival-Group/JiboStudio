import Procedure from "../flow-objects/Procedure";
declare class GojsLoader {
    static getName(uri: string): string;
    static getBase(uri: string): string;
    static loadProcedureRelative(currentUri: string, name: string): Procedure;
    static loadProcedure(uri: string): Procedure;
    static loadParsedProcedure(uri: string, base: any): Procedure;
}
export default GojsLoader;
