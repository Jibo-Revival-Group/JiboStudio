declare var _default: {
    version0: (rawTree: any) => any;
};
export default _default;
