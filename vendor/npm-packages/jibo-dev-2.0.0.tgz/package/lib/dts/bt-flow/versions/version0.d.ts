export default function (rawTree: any): any;
