export default function LiteralExpression(value: string): any;
