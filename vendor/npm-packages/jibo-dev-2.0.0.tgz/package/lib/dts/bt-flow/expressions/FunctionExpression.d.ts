export default function FunctionExpression(objectExpression: any, hasSelf: any): {
    "type": string;
    "id": any;
    "params": any[];
    "defaults": any[];
    "body": {
        "type": string;
        "body": {
            "type": string;
            "argument": any;
        }[];
    };
    "rest": any;
    "generator": boolean;
    "expression": boolean;
};
