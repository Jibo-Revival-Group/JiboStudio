declare var _default: (relativePath: any) => {
    "type": string;
    "id": any;
    "params": any[];
    "defaults": any[];
    "body": {
        "type": string;
        "body": {
            "type": string;
            "argument": {
                "type": string;
                "callee": {
                    "type": string;
                    "name": string;
                };
                "arguments": {
                    "type": string;
                    "value": any;
                    "raw": string;
                }[];
            };
        }[];
    };
    "generator": boolean;
    "expression": boolean;
};
export default _default;
