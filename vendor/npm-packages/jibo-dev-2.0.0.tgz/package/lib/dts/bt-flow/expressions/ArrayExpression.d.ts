declare class ArrayExpression {
    expression: {
        type: string;
        elements: any[];
    };
    constructor();
    push(value: any): void;
}
export default ArrayExpression;
