declare class ObjectExpression {
    expression: {
        type: string;
        properties: any[];
    };
    constructor(props?: any);
    addKeyValue(key: string, value: any): void;
}
export default ObjectExpression;
