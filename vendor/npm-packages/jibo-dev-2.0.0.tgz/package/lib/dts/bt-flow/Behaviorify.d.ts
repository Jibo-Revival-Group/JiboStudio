import core from './core';
/**
 * Converts a raw JSON data structure into a JavaScript module.
 * ```
 * import {Behaviorify} = require('jibo-dev');
 * const bt = new Behaviorify('/path/to/custom.bt');
 * console.log(bt.exec());
 * ```
 * @class Behaviorify
 * @param {String} filename The file name if the first argument is an Object.
 * @param {Object} [data] The `.bt` or `.flow` file data or path to file.
 */
declare class Behaviorify {
    /**
     * Current version of the behavior tree format
     * @name Behaviorify.CURRENT_VERSION
     * @type {Number}
     */
    static CURRENT_VERSION: number;
    data: any;
    filename: string;
    /**
     * Browserify transform
     * @method Behaviorify.transform
     * @private
     * @param {String} filename File name.
     * @param {String} source Buffer from source file.
     * @return {String} Output JavaScript module buffer.
     */
    static transform(filename: string, source: string): any;
    /**
     * Run behaviorify for the commandline.
     * @method Behaviorify.cli
     * @private
     */
    static cli(): void;
    /**
     * The core classes.
     * @method Behaviorify.core
     * @return {Map} Collection of core behavior and decorators.
     */
    static readonly core: typeof core;
    constructor(filename: string, data?: any);
    /**
     * Update the raw tree with deprecations.
     * @method Behaviorify#update
     */
    update(): void;
    /**
     * Convert the object.
     * @method Behaviorify#exec
     * @param {Object} [options] - Options.
     * @param {Boolean} [options.noRequirification] if true, the subflow/subtree references are left untouched.
     * @return {String} Resulting buffer JavaScript file.
     */
    exec(options?: any): string;
    /**
     * Clear and don't use after this.
     * @method Behaviorify#dispose
     * @private
     */
    dispose(): void;
    /**
     * Simple utility to read a file.
     * @method Behaviorify#readFile
     * @private
     * @param {String} file The local file path.
     * @return {String} Contents of the file.
     */
    private readFile(file);
}
export default Behaviorify;
