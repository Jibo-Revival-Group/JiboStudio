import { EventEmitter } from 'events';
/**
 * Statically check a `.flow` file and its dependencies for inconsistencies and missing resources.
 * ```
 * import {FlowLint} from 'jibo-dev';
 * var linter = new FlowLint(__dirname, '/full/path/to/file.flow');
 * linter.run();
 * console.log(linter.getErrorReport());
 * ```
 * @class FlowLint
 * @param {string} projectRoot Path to the skill's project-level directory.
 * @param {string} uri Path to the `.flow` file.
 */
declare class FlowLint {
    projectRoot: string;
    uri: string;
    procedures: {
        [key: string]: any;
    };
    flowRoot: any;
    private errors;
    /**
     * Command-line tool for validating a directory or single flow file.
     * @method FlowLint.cli
     * @private
     */
    static cli(): void;
    /**
     * Command-line tool for validating a directory or single flow file.
     * @method FlowLint.exec
     * @param {String} dir Directory containing flow files
     * @param {Boolean} [verbose=false] If we should load
     * @return {EventEmitter} Emits 'lintError', 'end' and 'log' event
     */
    static exec(dir: String, verbose?: boolean): EventEmitter;
    constructor(projectRoot: string, uri: string);
    /**
     * Run the preflight check.
     * @method FlowLint#run
     */
    run(): void;
    /**
     * Write discovered errors to the given file.
     * @method FlowLint#writeReportToFile
     * @param {string} filename
     */
    writeReportToFile(filename: string): void;
    /**
     * Format all the discovered errors into a report.
     * @method FlowLint#getErrorReport
     * @returns {string} Report of all discovered errors.
     */
    getErrorReport(): string;
    /**
     * Recursively load all the procedures reachable from the preflighted procedure.
     * @method FlowLint#loadProcedures
     * @private
     */
    private loadProcedures();
    /**
     * Load a procedure and all its dependents.
     * @method FlowLint#loadProcedure
     * @private
     * @param {Procedure} procedure
     */
    private loadProcedure(procedure);
    /**
     * Recursively load all the procedures reachable from the preflighted procedure.
     * @method FlowLint#loadProcedures
     * @private
     * @param {Procedure} procedure
     */
    private loadSubflows(procedure);
    /**
     * Gather up all the different transition values that a procedure returns to its parent via Flow.End.
     * @method FlowLint#loadReturnValues
     * @private
     * @param {Procedure} procedure
     */
    private loadReturnValues(procedure);
    /**
     * Check all the procedures found during loading.
     * @method FlowLint#checkProcedures
     * @private
     */
    private checkProcedures();
    /**
     * Get a sorted list of all the procedures that have been loaded.
     * @method FlowLint#getSortedProcedures
     * @private
     */
    private getSortedProcedures();
    /**
     * Check a procedure for consistency and missing resources.
     * @method FlowLint#checkProcedure
     * @private
     * @param {Procedure} procedure
     */
    private checkProcedure(procedure);
    /**
     * Ensure that correct number of transitions are used for each type of activity.
     * @method FlowLint#checkTransitionCounts
     * @private
     * @param {Procedure} procedure
     */
    private checkTransitionCounts(procedure);
    /**
     * Ensure that values returned from an activity (currently just Subflows) will match one of its outbound transitions.
     * @method FlowLint#checkTransitionValues
     * @private
     * @param {Procedure} procedure
     */
    private checkTransitionValues(procedure);
    /**
     * Ensure that the procedure has the correct number of Flow.Begin activities.
     * @method FlowLint#checkStartValidity
     * @private
     * @param {Procedure} procedure
     */
    private checkStartValidity(procedure);
    /**
     * Ensure that the resources referenced by each mim in the procedure are present.
     * @method FlowLint#checkMimReferences
     * @private
     * @param {Procedure} procedure
     */
    private checkMimReferences(procedure);
    /**
     * Ensure that a mim activity's referenced files are present (mim file, rule file, animation files).
     * @method FlowLint#checkMim
     * @private
     * @param {Activity} activity
     */
    private checkMim(activity);
    /**
     * Accumulate an error referring to a procedure.
     * @method FlowLint#addProcedureError
     * @private
     * @param {Procedure} procedure
     * @param {string} message
     * @param {string} code
     */
    private addProcedureError(procedure, message, code);
    /**
     * Accumulate an error referring to an activity.
     * @method FlowLint#addProcedureError
     * @private
     * @param {Activity} activity
     * @param {string} message
     * @param {string} code
     */
    private addActivityError(activity, message, code);
    /**
     * Sort the errors by procedure name, error code, activity type, and activity name.
     * @method FlowLint#getSortedErrors
     * @private
     * @returns {Error[]}
     */
    private getSortedErrors();
}
export default FlowLint;
