import { EventEmitter } from 'events';
/**
 * Callback for asynchronous rule conversion.
 * @callback Rulify~Callback
 * @param {Error} error If conversion failed.
 * @param {String} output The output file path.
 */
/**
 * Convert a `.rule` file to a `.fst` file.
 * ```
 * import {Rulify} from 'jibo-dev';
 * const fstPath = Rulify.sync('/path/to/file.rule');
 * console.log("FST file saved to: ", fstPath);
 * ```
 * @class Rulify
 */
export default class Rulify {
    private static _nlu;
    /**
     * Synchronous version of rulify.
     * @method Rulify.sync
     * @param {String} src Either the contents of the rule or the path to the source.
     * @param {String} output Name of file to write, will default to src with `.fst` extension.
     * @return {String} The output file saved.
     */
    static sync(src: any, output: any): any;
    /**
     * Asynchronous version of rulify.
     * @method Rulify.async
     * @param {String} src Either the contents of the rule or the path to the source.
     * @param {String} [output] Name of file to write, will default to src with `.fst` extension.
     * @param {Rulify~Callback} callback Called when the conversion completes.
     */
    static async(src: any, output: any, callback: any): void;
    /**
     * Execute the commandline interface
     * @method Rulify.cli
     * @private
     */
    static cli(): void;
    /**
     * Get the reference the NLU parser.
     * @method Rulify.nlu
     * @return {NLU} The nlu parser.
     */
    static readonly nlu: any;
    /**
     * Get the reference the NLU parser.
     * @method Rulify.exec
     * @param {Array<String>} files List of files to load
     * @param {String} input Input directory
     * @param {String} output Output directory
     * @param {Boolean} [verbose=false] Extra logging
     * @return {EventEmitter} Emitter dispatches 'end', 'fileError', 'compileError', and 'log'
     */
    static exec(input: string, output: string, verbose?: boolean): EventEmitter;
    /**
     * Convert file to .fst
     * @method Rulify.defaultOutput
     * @private
     * @param {String} file Convert
     * @return {String} File .fst path
     */
    private static defaultOutput(file);
    /**
     * Write the buffer from data string
     * @function fromString
     * @private
     * @param {String} data contents of .rule file
     * @param {String} output Path to file to save
     * @param {Rulify~Callback} callback Calls when write completes.
     */
    private static fromString(data, output, callback);
    /**
     * Create a buffer from data
     * @function toBuffer
     * @private
     * @param {String} data Contents of .rule file
     */
    private static toBuffer(data);
}
