/**
 * The config options
 * @interface JiboDev~JiboDevConfig
 */
export interface JiboDevConfig {
    /**
     * The folder to watch
     * @name JiboDev~JiboDevConfig#watch
     * @type {String}
     * @default src
     */
    watch?: string;
    /**
     * Entry point for the application
     * @name JiboDev~JiboDevConfig#app
     * @type {String}
     * @default src/index.ts
     */
    app?: string;
    /**
     * The output file name
     * @name JiboDev~JiboDevConfig#bundle
     * @type {String}
     * @default index.js
     */
    bundle?: string;
    /**
     * The name of the map file
     * @name JiboDev~JiboDevConfig#map
     * @type {String}
     * @default index.js.map
     */
    map?: string;
    /**
     * The folder to watch
     * @name JiboDev~JiboDevConfig#watch
     * @type {String}
     * @default tslint.json
     */
    tslint?: string;
    /**
     * Additional files to clean
     * @name JiboDev~JiboDevConfig#clean
     * @type {Array<String>}
     * @default []
     */
    clean?: string[];
    /**
     * Output folder for rules
     * @name JiboDev~JiboDevConfig#rules
     * @type {Array<String>}
     * @default rules
     */
    rules?: string;
    /**
     * Input folder for rules
     * @name JiboDev~JiboDevConfig#rulesSrc
     * @type {Array<String>}
     * @default src/rules
     */
    rulesSrc?: string;
    /**
     * Input folder for flow
     * @name JiboDev~JiboDevConfig#flowsSrc
     * @type {Array<String>}
     * @default src/flows
     */
    flowsSrc?: string;
}
/**
 * Provide the build process for skills.
 * @class JiboDev
 */
declare class JiboDev {
    dirname: string;
    config: JiboDevConfig;
    args: any;
    /**
     * Command line invokation of the jibo-dev build tools
     * @method JiboDev.cli
     */
    static cli(): void;
    /**
     * @constructor
     * @param {String} [dirname] The directory name to run tasks
     * @param {JiboDev~JiboDevConfig} [config] Optional configuration
     */
    constructor(dirname?: string, config?: JiboDevConfig);
    /**
     * Run as ask command.
     * @method JiboDev#run
     * @param {String} [task='build'] Name of the task: build, clean, watch
     * @return Promise<void> The promise when complete.
     */
    run(task: string): Promise<void>;
}
export default JiboDev;
