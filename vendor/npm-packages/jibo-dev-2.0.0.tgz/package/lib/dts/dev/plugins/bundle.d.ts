import { JiboDevConfig } from '../JiboDev';
export default function (options: JiboDevConfig, production: boolean, watch?: boolean): any;
