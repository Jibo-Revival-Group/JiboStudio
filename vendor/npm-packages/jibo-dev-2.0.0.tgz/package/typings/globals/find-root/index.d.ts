declare module "find-root" {
    function findRoot(start: string[]): string;
    function findRoot(start?: string): string;
    export = findRoot;
}