"use strict";

// NOTE: there's a limitation with npm v2 which does not allow
// for properly including .bin environment when the module
// is de-duped. This is required so that jibo-sdk downloads
// successfully. When migrating to npm v3, this can be removed.
const download = require('parser-download');

// Version of jibo-parser to download
const VERSION = '2.4.0';

// Quick and dirty verbose mode
const verbose = process.argv.indexOf('-v') > -1;

// Setting downloading for node
const node = {
    version: VERSION,
    type: 'auto',
    dir: 'parser-node',
    verbose: verbose
};

// Setting downloading for Electron 1.0.1
const electron = {
    version: VERSION,
    type: '47',
    dir: 'parser-electron',
    verbose: verbose
};

// Do the download of both parsers
download(node, err => {
    if (err) {
        console.error(err);
        return process.exit(1);
    }
    download(electron, err => {
        if (err) {
            console.error(err);
            return process.exit(1);
        }
        process.exit(0);
    });
});