# jibo-dev

Contains a collection of build tools specific for jibo.

| Name | Description |
|---|---|---|---|
| [**Rulify**](#rulify) | Compiles **.rule** files into **.fst** files. |
| [**Behaviorify**](#behaviorify) | Builds **.bt** files into **.js** files. |
| [**Flowify**](#flowify) | Builds **.flow** files into **.js** files. |
| [**BrowserifyTransform**](#browserifytransform) | Browserify transform for compiling **.bt** and **.flow** files into source. |
| [**FlowLint**](#flowlint) | Static analysis tools for **.flow** files. | 

## Rulify

#### Rulify.sync

Synchronous version to generate **.fst** files from **.rule** files.

```js
import {Rulify} from 'jibo-dev';
import path from 'path';
const output = Rulify.sync(
	path.resolve('./src/rules/main.rule'),
	path.resolve('./rules')
);
console.log(output);
```

#### Rulify.async

Asynchronous version to generate **.fst** files from **.rule** files.

```js
import {Rulify} from 'jibo-dev';
import path from 'path';
Rulify.async(
	path.resolve('./src/rules/main.rule'),
	path.resolve('./rules'), 
	(err) => {
		if (err) {
			console.error(err);
		}
	}
);
console.log(output);
```

#### Rulify.nlu

Get the NLU parser to get results.

```js
import {Rulify} from 'jibo-dev';
const nlu = Rulify.nlu;
const fst = nlu.read_fst_from_uri('file:///path/to/file.fst');
const parser = nlu.build_sentence_parser(fst);
const result = JSON.parse(parser.parse_sentence('hello world'));
```

### `rulify` Command-line

```bash
rulify --input ./src/rules --output ./rules
```

**Arguments**

* `--verbose` or `-v` Run in verbose mode, see more logs.
* `--input` or `-i` The input directory of *.rule files.
* `--output` or `-o` The output directory for rule files.

## Behaviorify

This will convert **.bt** files into JavaScript.

```js
import {Behaviorify} from 'jibo-dev';
const bt = new Behaviorify('/path/to/file.bt');
const result = bt.exec();
console.log(result);
```

* **constructor(file, [data])** Constructor accepts the path to the .bt file and optionally the JSON data if the .bt file was created dynamically.
* **exec()** Returns the string buffer of JavaScript output.
* **dispose()** Destroy the bt file and don't use after this.

### `behaviorify` Command-line

Converts **.bt** and **.flow** files to JavaScript output. 

```bash
behaviorify --input ./src/behaviors --output ./behaviors
```
_Note: it's highly recommended to use the BrowserifyTransform instead of building individual files._

**Arguments**

* `--verbose` or `-v` Run in verbose mode, see more logs.
* `--input` or `-i` The input directory of *.rule files.
* `--output` or `-o` The output directory for rule files.
* `--update` or `-u` Only upgrade the behavior files, if out of date.

## Flowify

This will convert **.flow** files into JavaScript.

```js
import {Flowify} from 'jibo-dev';
const flow = new Flowify('/path/to/file.flow');
const result = flow.exec();
console.log(result);
```

* **constructor(file, [data])** Constructor accepts the path to the .flow file and optionally the JSON data if the .flow file was created dynamically.
* **exec()** Returns the string buffer of JavaScript output.
* **dispose()** Destroy the .flow file and don't use after this.

_Note: the `behaviorify` command will also work for flow files. There's not explicit Flowify command-line tool._ 

## BrowserifyTransform

Can be used with [Browserify](http://browserify.org/) to automatically build **.flow** and **.bt** files into your source code. Strongly recommend using this over the commandline `behaviorify` tool.

#### package.json

Easy way to implement is to set browserify-transform as a transform in yoru package.json file within your project.

```json
{
    "browserify": {
        "transform": [
            "jibo-dev/browserify-transform"
        ]
    }
}
```

#### Browserify API

Alternatively, if implementing the browserify API, can use the transform here:

```js
const browserify = require('browserify');
browserify().transform('jibo-dev/browserify-transform');
```

## FlowLint

Tool design to make sure a Flow files contains all it's references, like MIMs, FSTs, etc.

```js
import {FlowLint} from 'jibo-dev';
const linter = new FlowLint(process.cwd(), '/path/to/file.flow');
linter.run();
console.log(linter.getErrorReport());
```

* **constructor(projectPath, uri)** Constructor to create a linter, arguments are the base project path, and the uri to the flow file.
* **run()** Execute the flow lint.
* **getErrorReport()** Get the report as a string.
* **writeReportToFile(logFile)** Write discovered errors to a given file.

### `flowlint` Command-line

```bash
flowlint --dir ./src/flows
```

**Arguments**

* `--verbose` or `-v` Run in verbose mode, see more logs.
* `--dir` or `-d` The input directory of *.flow files.
